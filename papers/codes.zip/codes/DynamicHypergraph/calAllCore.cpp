# include <iostream>
# include <string>
# include <unordered_map>
# include <fstream>
# include <sys/time.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "hypergraph.h"

using namespace std;

vector<int> splitStr(string strInput, string strSpt);

int main(int argc, char *argv[])
{
    string graphFile = argv[1];
    ifstream finGraph(graphFile.data());
    Hypergraph hypergraph;
    // 按行读取原图文件
    string edgeLine;
    string strSpt = "\t";
    while (getline(finGraph, edgeLine))
    {
        vector<int> input = splitStr(edgeLine, strSpt);
        hypergraph.addEdge(input);
    }
    hypergraph.coreV = hypergraph.coreDecomp();
    for (int i = 0; i < hypergraph.coreV.size(); i++)
    {
        cout << i << "\t" << hypergraph.coreV[i] << endl;
    }

    return 0;

}

vector<int> splitStr(string strInput, string strSpt)
{
    // 用strSpt分割strInput
    vector<string> vecStr;
    while (strInput.find(strSpt) != strInput.npos)
    {
        size_t pos = strInput.find(strSpt);
        string str2 = strInput.substr(0, pos);
        vecStr.push_back(str2);
        strInput = strInput.substr(pos+strSpt.size());
    }
    vecStr.push_back(strInput);
    // 将vector<string转成vector<int>
    vector<int> vecInt;
    for (int i = 0; i < vecStr.size(); i++)
    {
        string strTmp = vecStr[i];
        vecInt.push_back(atoi(strTmp.c_str()));
    }
    return vecInt;
}