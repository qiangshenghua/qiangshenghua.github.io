# include "hypergraph.h"

void Hypergraph::addEdge(vector<int> edge)
{
    // 这里不考虑超边重复的情况，请确保输入的数据没有重复的边，似乎支持存在重复边
    // 对于节点数小于2的边直接忽略
    // if (edge.size() < 2)
    // {
    //     return;
    // }
    int num = vvEdges.size();    // 插入的这条边的序号
    vvEdges.push_back(edge);    // 插入边
    edgeNum += 1;
    // 插入节点
    for (int i = 0; i < edge.size(); i++)
    {
        while (edge[i] + 1 > vertexNum)
        {
            vvVertices.push_back(vector<int>(0));
            vertexNum += 1;
        }
        vvVertices[edge[i]].push_back(num);
    }
    return;
}

void Hypergraph::init()
{
    visited.clear();
    visited.resize(vertexNum, false);
    removed.clear();
    removed.resize(vertexNum, false);
    eFlag.clear();
    eFlag.resize(edgeNum, false);
    mcd.clear();
    mcd.resize(vertexNum, 0);
    cd.clear();
    cd.resize(vertexNum, 0);
    // visitedVerticesNum = 0;
    // degree.resize(vertexNum, 0);
    // coreV.resize(vertexNum, 0);
    // coreE.resize(edgeNum, 0);
    return;
}

vector<int> Hypergraph::coreDecomp()
{
    int a = 0;
    int b = 0;
    vector<int> bin, pos, vert, deg;
    int maxDegree = 0;
    int n = vertexNum;
    for (int u = 0; u < n; u++)
    {
        pos.push_back(0);
        vert.push_back(0);
        int uSize = vvVertices[u].size();
        deg.push_back(uSize);
        maxDegree = (maxDegree > uSize) ? maxDegree : uSize;
    }
    for (int k = 0; k <= maxDegree; k++)
    {
        bin.push_back(0);
    }
    for (int u = 0; u < n; u++)
    {
        bin[deg[u]]++;
    }
    int start = 0;
    for (int k = 0; k <= maxDegree; k++)
    {
        int num = bin[k];
        bin[k] = start;
        start += num;
    }
    for (int u = 0; u < n; u++)
    {
        pos[u] = bin[deg[u]];
        vert[pos[u]] = u;
        bin[deg[u]]++;
    }
    for (int d = maxDegree; d > 0; d--)
    {
        bin[d] = bin[d-1];
    }
    bin[0] = 0;
    int du, pu, pw, w;
    unordered_set<int> sEdges;
    for (int i = 0; i < n; i++)
    {
        int v = vert[i];
        for (int j = 0; j < vvVertices[v].size(); j++)
        {
            int e = vvVertices[v][j];
            if (sEdges.find(e) != sEdges.end())
            {
                continue;
            }
            sEdges.insert(e);
            vector<int> neighbor = vvEdges[e];
            for (int k = 0; k < neighbor.size(); k++)
            {
                int u = neighbor[k];
                if (u != v && deg[u] > deg[v])
                {
                    du = deg[u];
                    pu = pos[u];
                    pw = bin[du];
                    w = vert[pw];
                    if (u != w)
                    {
                        pos[u] = pw;
                        vert[pu] = w;
                        pos[w] = pu;
                        vert[pw] = u;
                    }
                    bin[du]++;
                    deg[u]--;
                }
            }
        }
    }
    return deg;
}

void Hypergraph::vertDeletion(unordered_map<int, vector<int>> mpDeletedVert)
{
    // int a = 0;
    // int b = 0;
    // int c = 0;
    visitedVerticesNum = 0;
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (deleteVertFromEdge(edge, vVert) == false)
        {
            return;
        }
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        vector<int> vecVmin2 = findMinVertices(vvEdges[edge]);
        int kmin2 = findMinCore(vvEdges[edge]);
        // 有可能删除节点后超边不存在（超边中没有节点了）
        // 如果kmin2小于0，说明超边中没有节点，这种情况下只需要考虑vecVmin为根
        kmin2 = (kmin2 < 0) ? kmin : kmin2;
        if (kmin > kmin2)
        {
            // a++;
            ;
        }
        else if (kmin == kmin2)
        {
            // b++;
            deleteFunc(vecVmin);
        }
        else
        {
            // c++;
            deleteFunc(vecVmin);
            insertFunc(vecVmin2);
        }
        // if (compare() == false)
        //     cout << edge << ": false" << endl;
        // iii++;
    }
    // cout << "D: " << a << "\t" << b << "\t" << c << endl;
    return;
}

void Hypergraph::vertInsertion(unordered_map<int, vector<int>> mpInsertedVert)
{
    // int a = 0;
    // int b = 0;
    // int c = 0;
    visitedVerticesNum = 0;
    for (auto it = mpInsertedVert.begin(); it != mpInsertedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        vector<int> vecVmin2 = findMinVertices(vvEdges[edge]);
        int kmin2 = findMinCore(vvEdges[edge]);
        kmin2 = (kmin2 < 0) ? kmin : kmin2;
        if (insertVertToEdge(edge, vVert) == false)
        {
            return;
        }
        if (kmin > kmin2)
        {
            // a++;
            ;
        }
        else if (kmin == kmin2)
        {
            // b++;
            insertFunc(vecVmin);
        }
        else
        {
            // c++;
            insertFunc(vecVmin);
            deleteFunc(vecVmin2);
        }
    }
    // cout << "I: " << a << "\t" << b << "\t" << c << endl;
    return;
}

/**
 * @brief 从传入的节点集中找到核值最小的节点集
 * 
 * @param vVertices ：节点集，传入时确保非空
 * @return vector<int> ：核值最小的节点集
 */
vector<int> Hypergraph::findMinVertices(vector<int> vVertices)
{

    vector<int> vRes;
    if (vVertices.size() == 0)
    {
        return vRes;
    }

    int minCoreNum = coreV[vVertices[0]];
    for (int i = 0; i < vVertices.size(); i++)
    {
        if (coreV[vVertices[i]] < minCoreNum)
        {
            minCoreNum = coreV[vVertices[i]];
            vRes.clear();
            vRes.push_back(vVertices[i]);
        }
        else if (coreV[vVertices[i]] == minCoreNum)
        {
            vRes.push_back(vVertices[i]);
        }
        else
        {
            ;
        }
    }
    return vRes;
}

/**
 * @brief 给定节点集，找到这些节点中的最小核值
 * 
 * @param vVertices 传入的节点集，传入时确保非空
 * @return int 最小核值
 */
int Hypergraph::findMinCore(vector<int> vVertices)
{
    if (vVertices.size() == 0)
    {
        return -1;
    }
    int minCoreNum = coreV[vVertices[0]];
    for (int i = 0; i < vVertices.size(); i++)
    {
        minCoreNum = (minCoreNum < coreV[vVertices[i]]) ? minCoreNum : coreV[vVertices[i]];
    }
    return minCoreNum;
}

/**
 * @brief 计算节点v的mcd值
 * 
 * @param v 待计算mcd的节点
 * @return int 节点v的mcd值
 */
int Hypergraph::computeMcd(int v)
{
    int mcdV = 0;
    vector<int> vEdges = vvVertices[v];
    for (int i = 0; i < vEdges.size(); i++)
    {
        vector<int> neighbor = vvEdges[vEdges[i]];
        // if (neighbor.size() < 2)
        // {
        //     continue;
        // }
        int edgeCore = findMinCore(neighbor);
        if (edgeCore >= coreV[v])
        {
            mcdV++;
        }
    }
    return mcdV;
}

/**
 * @brief 在超边中删除节点
 * 
 * @param mpDeletedVert key：超边 value：待删除的节点
 * @return true ：删除成功
 * @return false ：删除失败
 */
bool Hypergraph::deleteVertFromEdge(unordered_map<int, vector<int>> mpDeletedVert)
{
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (edge >= edgeNum)
        {
            cout << "deleted edge is out of range" << endl;
            return false;
        }
        vector<int> oldVert = vvEdges[edge];    // 边edge原先拥有的节点
        if (oldVert.size() - vVert.size() < 0)
        {
            return false;
        }
        // 在vvEdges中删除超边中的节点
        unordered_set<int> usVert(oldVert.begin(), oldVert.end());
        for (int i = 0; i < vVert.size(); i++)
        {
            if (usVert.find(vVert[i]) == usVert.end())
            {
                return false;
            }
            usVert.erase(usVert.find(vVert[i]));
        }
        vector<int> newVert(usVert.begin(), usVert.end());
        if (newVert.size() < 2)
        {
            // 相当于这条超边已经不存在了
            vvEdges[edge].clear();
            vVert.insert(vVert.end(), newVert.begin(), newVert.end());
        }
        else
        {
            vvEdges[edge] = newVert;
        }
        // 在vvVertices中删除包含这个节点的超边
        for (int i = 0; i < vVert.size(); i++)
        {
            vector<int> oldEdge = vvVertices[vVert[i]];
            vector<int> newEdge;
            for (int j = 0; j < oldEdge.size(); j++)
            {
                if (oldEdge[j] != edge)
                {
                    newEdge.push_back(oldEdge[j]);
                }
            }
            vvVertices[vVert[i]] = newEdge;
        }

    }
    return true;
}

/**
 * @brief 在超边中删除节点
 * 
 * @param 
 * @return true ：删除成功
 * @return false ：删除失败
 */
bool Hypergraph::deleteVertFromEdge(int e, vector<int> vecV)
{
    int edge = e;
    vector<int> vVert = vecV;
    if (edge >= edgeNum)
    {
        cout << "deleted edge is out of range" << endl;
        return false;
    }
    vector<int> oldVert = vvEdges[edge];    // 边edge原先拥有的节点
    if (oldVert.size() - vVert.size() < 0)
    {
        return false;
    }
    // 在vvEdges中删除超边中的节点
    unordered_set<int> usVert(oldVert.begin(), oldVert.end());
    for (int i = 0; i < vVert.size(); i++)
    {
        if (usVert.find(vVert[i]) == usVert.end())
        {
            return false;
        }
        usVert.erase(usVert.find(vVert[i]));
    }
    vector<int> newVert(usVert.begin(), usVert.end());
    // if (newVert.size() < 2)
    // {
    //     // 相当于这条超边已经不存在了
    //     vvEdges[edge].clear();
    //     vVert.insert(vVert.end(), newVert.begin(), newVert.end());
    // }
    // else
    // {
    //     vvEdges[edge] = newVert;
    // }
    vvEdges[edge] = newVert;
    // 在vvVertices中删除包含这个节点的超边
    for (int i = 0; i < vVert.size(); i++)
    {
        vector<int> oldEdge = vvVertices[vVert[i]];
        vector<int> newEdge;
        for (int j = 0; j < oldEdge.size(); j++)
        {
            if (oldEdge[j] != edge)
            {
                newEdge.push_back(oldEdge[j]);
            }
        }
        vvVertices[vVert[i]] = newEdge;
    }

    return true;
}

/**
 * @brief 向超边插入节点
 * 
 * @param e 待插入节点的超边
 * @param vecV 待插入的节点集
 * @return true 
 * @return false 
 */
bool Hypergraph::insertVertToEdge(int e, vector<int> vecV)
{
    // 修改vvEdges[e]，插入节点集
    vector<int> oldVert = vvEdges[e];    // 边e原先拥有的节点
    unordered_set<int> usVert(oldVert.begin(), oldVert.end());
    for (int i = 0; i < vecV.size(); i++)
    {
        if (usVert.find(vecV[i]) != usVert.end())
        {
            return false;
        }
        usVert.insert(vecV[i]);
    }
    vector<int> newVert(usVert.begin(), usVert.end());
    vvEdges[e] = newVert;
    // 在每个节点中添加边
    for (int i = 0; i < vecV.size(); i++)
    {
        vvVertices[vecV[i]].push_back(e);
    }
    return true;
}

void Hypergraph::deleteFunc(vector<int> root)
{
    init();
    for (int i = 0; i < root.size(); i++)
    {
        visitedVerticesNum++;
        int v = root[i];
        int k = coreV[v];
        if (visited[v] == false)
        {
            visited[v] = true;
            mcd[v] = computeMcd(v);
            cd[v] = cd[v] + mcd[v];
        }
        if (removed[v] == false && cd[v] < k)
        {
            removed[v] = true;
            stack<int> stk;
            stk.push(v);
            while (!stk.empty())
            {
                int u = stk.top();
                stk.pop();
                vector<int> edgesofV = vvVertices[u];
                for (int j = 0; j < edgesofV.size(); j++)
                {
                    vector<int> vertofEdge = vvEdges[edgesofV[j]];
                    if ((findMinCore(vertofEdge) == k) && (eFlag[edgesofV[j]] == false))
                    {
                        eFlag[edgesofV[j]] = true;
                        for (int ij = 0; ij < vertofEdge.size(); ij++)
                        {
                            visitedVerticesNum++;
                            int w = vertofEdge[ij];
                            if (coreV[w] == k && w != u)
                            {
                                if (visited[w] == false)
                                {
                                    visited[w] = true;
                                    mcd[w] = computeMcd(w);
                                    cd[w] = cd[w] + mcd[w];
                                }
                                cd[w] = cd[w] - 1;
                                if (cd[w] < k && removed[w] == false)
                                {
                                    stk.push(w);
                                    removed[w] = true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    for (int i = 0; i < vertexNum; i++)
    {
        if (visited[i] == true && removed[i] == true)
        {
            coreV[i] = coreV[i] - 1;
        }
    }
    return;
}

void Hypergraph::insertFunc(vector<int> root)
{
    init();
    for (int i = 0; i < root.size(); i++)
    {
        visitedVerticesNum++;
        int v = root[i];
        if (visited[v] == true)
        {
            continue;
        }
        int k = coreV[v];
        visited[v] = true;
        mcd[v] = computeMcd(v);
        cd[v] = cd[v] + mcd[v];
        stack<int> stk1;
        stk1.push(v);
        while (!stk1.empty())
        {
            int u = stk1.top();
            stk1.pop();
            if (cd[u] > k)
            {
                vector<int> edgesofV = vvVertices[u];
                for (int j = 0; j < edgesofV.size(); j++)
                {
                    vector<int> vertofEdge = vvEdges[edgesofV[j]];
                    if (findMinCore(vertofEdge) == k)
                    {
                        for (int ij = 0; ij < vertofEdge.size(); ij++)
                        {
                            visitedVerticesNum++;
                            int w = vertofEdge[ij];
                            if (coreV[w] == k && w != u)
                            {
                                if (visited[w] == false)
                                {
                                    visited[w] = true;
                                    mcd[w] = computeMcd(w);
                                    cd[w] = cd[w] + mcd[w];
                                    stk1.push(w);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (removed[u] == false)
                {
                    stack<int> stk2;
                    stk2.push(u);
                    removed[u] = true;
                    while (!stk2.empty())
                    {
                        int x = stk2.top();
                        stk2.pop();
                        vector<int> edgesofX = vvVertices[x];
                        for (int j = 0; j < edgesofX.size(); j++)
                        {
                            vector<int> vertofEdge = vvEdges[edgesofX[j]];
                            if ((findMinCore(vertofEdge) == k) && (eFlag[edgesofX[j]] == false))
                            {
                                eFlag[edgesofX[j]] = true;
                                for (int ij = 0; ij < vertofEdge.size(); ij++)
                                {
                                    visitedVerticesNum++;
                                    int y = vertofEdge[ij];
                                    if (coreV[y] == k && y != x)
                                    {
                                        cd[y] = cd[y] - 1;
                                        if (removed[y] == false && cd[y] == k)
                                        {
                                            removed[y] = true;
                                            stk2.push(y);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    for (int i = 0; i < vertexNum; i++)
    {
        if (visited[i] == true && removed[i] == false)
        {
            coreV[i] = coreV[i] + 1;
        }
    }
    return;
}

bool Hypergraph::compare()
{
    vector<int> staticCore = coreDecomp();
    if (staticCore.size() != coreV.size())
    {
        return false;
    }
    for (int i = 0; i < coreV.size(); i++)
    {
        if (staticCore[i] != coreV[i])
        {
            cout << i << " " << staticCore[i] << " " << coreV[i] << endl;
            return false;
        }
    }
    return true;
}

/**
 * @brief 通过静态分解的方式进行核值维护（删除情况）
 * 
 * @param mpDeletedVert 待删除边集
 */
void Hypergraph::staticDeletion(unordered_map<int, vector<int>> mpDeletedVert)
{
    // 在原图中将边删除
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (deleteVertFromEdge(edge, vVert) == false)
        {
            return;
        }
    }
    // 静态核值分解
    coreV = coreDecomp();
    return;
}

/**
 * @brief 通过静态分解的方式进行核值维护（插入情况）
 * 
 * @param mpDeletedVert 
 */
void Hypergraph::staticInsertion(unordered_map<int, vector<int>> mpDeletedVert)
{
    // 在原图中将边插入
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (insertVertToEdge(edge, vVert) == false)
        {
            return;
        }
    }
    // 静态核值分解
    coreV = coreDecomp();
    return;
}

/**
 * @brief ICDE2021 删除情况下核值维护
 * 
 * @param mpDeletedVert 
 */
void Hypergraph::icdeDeletion(unordered_map<int, vector<int>> mpDeletedVert)
{
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int oldEdge = it->first;
        vector<int> oldVertices = vvEdges[oldEdge];
        // 先删除旧边
        if (deleteVertFromEdge(oldEdge, oldVertices) == false)
        {
            return;
        }
        // 删除之后更新核值
        vector<int> vecVmin = findMinVertices(oldVertices);
        deleteFunc(vecVmin);
        
        // 再插入新边
        vector<int> deletedVertices = it->second;
        sort(oldVertices.begin(), oldVertices.end());
        sort(deletedVertices.begin(), deletedVertices.end());
        vector<int> newVertices;
        set_difference(oldVertices.begin(), oldVertices.end(), deletedVertices.begin(), deletedVertices.end(), inserter(newVertices, newVertices.begin()));
        if (insertVertToEdge(oldEdge, newVertices) == false)
        {
            return;
        }
        // 插入之后更新核值
        vecVmin = findMinVertices(newVertices);
        insertFunc(vecVmin);
    }
    return;
}

/**
 * @brief ICDE2021 插入情况下核值维护
 * 
 * @param mpDeletedVert 
 */
void Hypergraph::icdeInsertion(unordered_map<int, vector<int>> mpDeletedVert)
{
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int oldEdge = it->first;
        vector<int> oldVertices = vvEdges[oldEdge];
        // 先删除旧边
        if (deleteVertFromEdge(oldEdge, oldVertices) == false)
        {
            return;
        }
        // 删除之后更新核值
        vector<int> vecVmin = findMinVertices(oldVertices);
        deleteFunc(vecVmin);
        
        // 再插入新边
        vector<int> newVertices = it->second;
        newVertices.insert(newVertices.end(), oldVertices.begin(), oldVertices.end());
        if (insertVertToEdge(oldEdge, newVertices) == false)
        {
            return;
        }
        // 插入之后更新核值
        vecVmin = findMinVertices(newVertices);
        insertFunc(vecVmin);
    }
    return;
}