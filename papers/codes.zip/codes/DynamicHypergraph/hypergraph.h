# include <iostream>
# include <vector>
# include <unordered_set>
# include <unordered_map>
# include <stack>
# include <algorithm>

using namespace std;

class Hypergraph {
public:
    int edgeNum;    // 超边数
    int vertexNum;    // 节点数
    long visitedVerticesNum;    // 访问的节点数
    vector<vector<int>> vvVertices;    // vvVertices[i]表示节点i所属的超边的集合
    vector<vector<int>> vvEdges;    // vvEdges[i]表示超边i所包含的节点集合
    vector<bool> visited;
    vector<bool> removed;
    vector<bool> eFlag;
    vector<int> mcd;
    vector<int> cd;
    vector<int> degree;
    vector<int> coreV;
    vector<int> coreE;

    Hypergraph() {edgeNum = 0; vertexNum = 0;}
    ~Hypergraph() {}

    void addEdge(vector<int> edge);
    void init();
    // 核值分解，将计算出的核值返回
    vector<int> coreDecomp();
    // 调用静态核值分解方法进行核值维护(删除情况)
    void staticDeletion(unordered_map<int, vector<int>> mpDeletedVert);
    // 调用静态核值分解方法进行核值维护(插入情况)
    void staticInsertion(unordered_map<int, vector<int>> mpDeletedVert);
    // ICDE2021删除
    void icdeDeletion(unordered_map<int, vector<int>> mpDeletedVert);
    // ICDE2021插入
    void icdeInsertion(unordered_map<int, vector<int>> mpDeletedVert);
    // 处理超边中节点删除的情况，key是超边，value是该超边中被删除的节点
    void vertDeletion(unordered_map<int, vector<int>> mpDeletedVert);
    bool deleteVertFromEdge(unordered_map<int, vector<int>> mpDeletedVert);
    bool deleteVertFromEdge(int e, vector<int> vecV);
    void deleteFunc(vector<int> root);
    void vertInsertion(unordered_map<int, vector<int>> mpDeletedVert);
    bool insertVertToEdge(int e, vector<int> vecV);
    void insertFunc(vector<int> root);
    bool compare();

private:
    vector<int> findMinVertices(vector<int> vVertices);
    int findMinCore(vector<int> vVertices);
    int computeMcd(int v);
};