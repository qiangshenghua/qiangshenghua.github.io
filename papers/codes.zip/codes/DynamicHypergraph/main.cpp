#include <iostream>
#include <string>
#include <unordered_map>
#include <fstream>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hypergraph.h"

using namespace std;

vector<int> splitStr(string strInput, string strSpt);

int main(int argc, char *argv[])
{
    // Hypergraph hypergraph;
    // vector<int> a0 = {0, 1, 2};
    // vector<int> a1 = {0, 3, 4};
    // vector<int> a2 = {0, 3, 5};
    // vector<int> a3 = {0, 4, 5};
    // vector<int> a4 = {3, 4, 5};
    // vector<int> a5 = {1, 3, 4};
    // vector<int> a6 = {4, 5};
    // hypergraph.addEdge(a0);
    // hypergraph.addEdge(a1);
    // hypergraph.addEdge(a2);
    // hypergraph.addEdge(a3);
    // hypergraph.addEdge(a4);
    // hypergraph.addEdge(a5);
    // hypergraph.addEdge(a6);

    // hypergraph.coreV = hypergraph.coreDecomp();

    // vector<int> vecD = {1};
    // unordered_map<int, vector<int>> unMap;
    // unMap[6] = vecD;

    // hypergraph.vertInsertion(unMap);
    // cout << hypergraph.compare() << endl;

    if (argc < 5)
    {
        cout << "Usage: -c(sequential)/-l(LCYLC)/-s(static) graph_filename edge_filename threadnum" << endl;
        return 0;
    }

    string graphFile = argv[2];
    string edgeFile = argv[3];
    int threadNum = atoi(argv[4]);
    ifstream finGraph(graphFile.data());
    ifstream finEdge(edgeFile.data());
    if (!finGraph)
    {
        cout << "Error opening " << graphFile << " for input" << endl;
        return 0;
    }
    Hypergraph hypergraph;
    // 按行读取原图文件
    string edgeLine;
    string strSpt = "\t";
    while (getline(finGraph, edgeLine))
    {
        vector<int> input = splitStr(edgeLine, strSpt);
        hypergraph.addEdge(input);
    }
    // 按行读取更新图文件
    if (!finEdge)
    {
        cout << "Error opening " << edgeFile << " for input" << endl;
        return 0;
    }
    unordered_map<int, vector<int>> mpDeletedVert;
    // int flag = 0;
    while (getline(finEdge, edgeLine))
    {
        vector<int> input = splitStr(edgeLine, strSpt);
        int e = input[0];
        vector<int> vs;
        vs.assign(input.begin() + 1, input.end());
        mpDeletedVert[e] = vs;
        // if (flag >= 50)
        // {
        //     mpDeletedVert[e] = vs;
        // }
        // flag += 1;
    }

    struct timeval t_start, t_end, f_start, f_end;

    // 静态分解
    // gettimeofday(&t_start, NULL);
    hypergraph.coreV = hypergraph.coreDecomp();
    // gettimeofday(&t_end, NULL);
    // double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
    // std::cout << "core decomposition" << '\t' << del_t << std::endl;

    // 静态核值分解进行核值维护
    if (strcmp(argv[1], "-s") == 0)
    {
        gettimeofday(&t_start, NULL);
        hypergraph.staticDeletion(mpDeletedVert);
        gettimeofday(&t_end, NULL);
        double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Delete" << '\t' << del_t << std::endl;

        gettimeofday(&t_start, NULL);
        hypergraph.staticInsertion(mpDeletedVert);
        gettimeofday(&t_end, NULL);
        double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Insert" << '\t' << ins_t << std::endl;
    }
    // ICDE2021 baseline
    else if (strcmp(argv[1], "-l") == 0)
    {
        gettimeofday(&t_start, NULL);
        hypergraph.icdeDeletion(mpDeletedVert);
        gettimeofday(&t_end, NULL);
        double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Delete" << '\t' << del_t << std::endl;

        gettimeofday(&t_start, NULL);
        hypergraph.icdeInsertion(mpDeletedVert);
        gettimeofday(&t_end, NULL);
        double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Insert" << '\t' << ins_t << std::endl;
    }
    // 串行算法核值维护
    else if (strcmp(argv[1], "-c") == 0)
    {
        gettimeofday(&t_start, NULL);
        hypergraph.vertDeletion(mpDeletedVert);
        gettimeofday(&t_end, NULL);
        double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Delete" << '\t' << del_t << std::endl;
        // cout << "delete" << '\t' << hypergraph.visitedVerticesNum << endl;

        gettimeofday(&t_start, NULL);
        hypergraph.vertInsertion(mpDeletedVert);
        gettimeofday(&t_end, NULL);
        double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Insert" << '\t' << ins_t << std::endl;
        // cout << "insert" << '\t' << hypergraph.visitedVerticesNum << endl;
    }
    // 并行算法核值维护
    else if (strcmp(argv[1], "-p") == 0)
    {
    }
    else
    {
        // gettimeofday(&t_start, NULL);
        // hypergraph.coreDecomp();
        // gettimeofday(&t_end, NULL);
        // double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        // std::cout << "static" << '\t' << del_t << std::endl;
        cout << "wrong params!" << endl;
    }

    // mpDeletedVert.clear();
    // mpDeletedVert[62723] = {60};
    // hypergraph.vertDeletion(mpDeletedVert);
    // cout << hypergraph.compare() << endl;
    // hypergraph.vertInsertion(mpDeletedVert);
    // cout << hypergraph.compare() << endl;

    finGraph.close();
    finEdge.close();
    return 0;
}

// 将输入的字符串分割
vector<int> splitStr(string strInput, string strSpt)
{
    // 用strSpt分割strInput
    vector<string> vecStr;
    while (strInput.find(strSpt) != strInput.npos)
    {
        size_t pos = strInput.find(strSpt);
        string str2 = strInput.substr(0, pos);
        vecStr.push_back(str2);
        strInput = strInput.substr(pos + strSpt.size());
    }
    vecStr.push_back(strInput);
    // 将vector<string转成vector<int>
    vector<int> vecInt;
    for (int i = 0; i < vecStr.size(); i++)
    {
        string strTmp = vecStr[i];
        vecInt.push_back(atoi(strTmp.c_str()));
    }
    return vecInt;
}