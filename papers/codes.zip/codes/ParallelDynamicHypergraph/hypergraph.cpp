# include "hypergraph.h"

void Hypergraph::addEdge(vector<int> edge)
{
    // 这里不考虑超边重复的情况，请确保输入的数据没有重复的边，似乎支持存在重复边
    // 对于节点数小于2的边直接忽略
    // if (edge.size() < 2)
    // {
    //     return;
    // }
    int num = vvEdges.size();    // 插入的这条边的序号
    vvEdges.push_back(edge);    // 插入边
    edgeNum += 1;
    // 插入节点
    for (int i = 0; i < edge.size(); i++)
    {
        while (edge[i] + 1 > vertexNum)
        {
            vvVertices.push_back(vector<int>(0));
            vertexNum += 1;
        }
        vvVertices[edge[i]].push_back(num);
    }
    return;
}

void Hypergraph::init()
{
    visited.clear();
    visited.resize(vertexNum, false);
    removed.clear();
    removed.resize(vertexNum, false);
    eFlag.clear();
    eFlag.resize(edgeNum, false);
    mcd.clear();
    mcd.resize(vertexNum, 0);
    cd.clear();
    cd.resize(vertexNum, 0);
    // degree.resize(vertexNum, 0);
    // coreV.resize(vertexNum, 0);
    // coreE.resize(edgeNum, 0);
    return;
}

vector<int> Hypergraph::coreDecomp()
{
    int a = 0;
    int b = 0;
    vector<int> bin, pos, vert, deg;
    int maxDegree = 0;
    int n = vertexNum;
    for (int u = 0; u < n; u++)
    {
        pos.push_back(0);
        vert.push_back(0);
        int uSize = vvVertices[u].size();
        deg.push_back(uSize);
        maxDegree = (maxDegree > uSize) ? maxDegree : uSize;
    }
    for (int k = 0; k <= maxDegree; k++)
    {
        bin.push_back(0);
    }
    for (int u = 0; u < n; u++)
    {
        bin[deg[u]]++;
    }
    int start = 0;
    for (int k = 0; k <= maxDegree; k++)
    {
        int num = bin[k];
        bin[k] = start;
        start += num;
    }
    for (int u = 0; u < n; u++)
    {
        pos[u] = bin[deg[u]];
        vert[pos[u]] = u;
        bin[deg[u]]++;
    }
    for (int d = maxDegree; d > 0; d--)
    {
        bin[d] = bin[d-1];
    }
    bin[0] = 0;
    int du, pu, pw, w;
    unordered_set<int> sEdges;
    for (int i = 0; i < n; i++)
    {
        int v = vert[i];
        for (int j = 0; j < vvVertices[v].size(); j++)
        {
            int e = vvVertices[v][j];
            if (sEdges.find(e) != sEdges.end())
            {
                continue;
            }
            sEdges.insert(e);
            vector<int> neighbor = vvEdges[e];
            for (int k = 0; k < neighbor.size(); k++)
            {
                int u = neighbor[k];
                if (u != v && deg[u] > deg[v])
                {
                    du = deg[u];
                    pu = pos[u];
                    pw = bin[du];
                    w = vert[pw];
                    if (u != w)
                    {
                        pos[u] = pw;
                        vert[pu] = w;
                        pos[w] = pu;
                        vert[pw] = u;
                    }
                    bin[du]++;
                    deg[u]--;
                }
            }
        }
    }
    return deg;
}

void Hypergraph::vertDeletion(unordered_map<int, vector<int>> mpDeletedVert)
{
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (deleteVertFromEdge(edge, vVert) == false)
        {
            return;
        }
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        vector<int> vecVmin2 = findMinVertices(vvEdges[edge]);
        int kmin2 = findMinCore(vvEdges[edge]);
        // 有可能删除节点后超边不存在（超边中没有节点了）
        // 如果kmin2小于0，说明超边中没有节点，这种情况下只需要考虑vecVmin为根
        kmin2 = (kmin2 < 0) ? kmin : kmin2;
        if (kmin > kmin2)
        {
            ;
        }
        else if (kmin == kmin2)
        {
            deleteFunc(vecVmin);
        }
        else
        {
            deleteFunc(vecVmin);
            insertFunc(vecVmin2);
        }
    }
    return;
}

void Hypergraph::vertInsertion(unordered_map<int, vector<int>> mpInsertedVert)
{
    for (auto it = mpInsertedVert.begin(); it != mpInsertedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        vector<int> vecVmin2 = findMinVertices(vvEdges[edge]);
        int kmin2 = findMinCore(vvEdges[edge]);
        kmin2 = (kmin2 < 0) ? kmin : kmin2;
        if (insertVertToEdge(edge, vVert) == false)
        {
            return;
        }
        if (kmin > kmin2)
        {
            ;
        }
        else if (kmin == kmin2)
        {
            insertFunc(vecVmin);
        }
        else
        {
            insertFunc(vecVmin);
            deleteFunc(vecVmin2);
        }
    }
    return;
}

/**
 * @brief 从传入的节点集中找到核值最小的节点集
 * 
 * @param vVertices ：节点集，传入时确保非空
 * @return vector<int> ：核值最小的节点集
 */
vector<int> Hypergraph::findMinVertices(vector<int> vVertices)
{

    vector<int> vRes;
    if (vVertices.size() == 0)
    {
        return vRes;
    }

    int minCoreNum = coreV[vVertices[0]];
    for (int i = 0; i < vVertices.size(); i++)
    {
        if (coreV[vVertices[i]] < minCoreNum)
        {
            minCoreNum = coreV[vVertices[i]];
            vRes.clear();
            vRes.push_back(vVertices[i]);
        }
        else if (coreV[vVertices[i]] == minCoreNum)
        {
            vRes.push_back(vVertices[i]);
        }
        else
        {
            ;
        }
    }
    return vRes;
}

/**
 * @brief 给定节点集，找到这些节点中的最小核值
 * 
 * @param vVertices 传入的节点集，传入时确保非空
 * @return int 最小核值
 */
int Hypergraph::findMinCore(vector<int> vVertices)
{
    if (vVertices.size() == 0)
    {
        return -1;
    }
    int minCoreNum = coreV[vVertices[0]];
    for (int i = 0; i < vVertices.size(); i++)
    {
        minCoreNum = (minCoreNum < coreV[vVertices[i]]) ? minCoreNum : coreV[vVertices[i]];
    }
    return minCoreNum;
}

/**
 * @brief 计算节点v的mcd值
 * 
 * @param v 待计算mcd的节点
 * @return int 节点v的mcd值
 */
int Hypergraph::computeMcd(int v)
{
    int mcdV = 0;
    vector<int> vEdges = vvVertices[v];
    for (int i = 0; i < vEdges.size(); i++)
    {
        vector<int> neighbor = vvEdges[vEdges[i]];
        // if (neighbor.size() < 2)
        // {
        //     continue;
        // }
        int edgeCore = findMinCore(neighbor);
        if (edgeCore >= coreV[v])
        {
            mcdV++;
        }
    }
    return mcdV;
}

/**
 * @brief 在超边中删除节点
 * 
 * @param mpDeletedVert key：超边 value：待删除的节点
 * @return true ：删除成功
 * @return false ：删除失败
 */
bool Hypergraph::deleteVertFromEdge(unordered_map<int, vector<int>> mpDeletedVert)
{
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (edge >= edgeNum)
        {
            cout << "deleted edge is out of range" << endl;
            return false;
        }
        vector<int> oldVert = vvEdges[edge];    // 边edge原先拥有的节点
        if (oldVert.size() - vVert.size() < 0)
        {
            return false;
        }
        // 在vvEdges中删除超边中的节点
        unordered_set<int> usVert(oldVert.begin(), oldVert.end());
        for (int i = 0; i < vVert.size(); i++)
        {
            if (usVert.find(vVert[i]) == usVert.end())
            {
                return false;
            }
            usVert.erase(usVert.find(vVert[i]));
        }
        vector<int> newVert(usVert.begin(), usVert.end());
        if (newVert.size() < 2)
        {
            // 相当于这条超边已经不存在了
            vvEdges[edge].clear();
            vVert.insert(vVert.end(), newVert.begin(), newVert.end());
        }
        else
        {
            vvEdges[edge] = newVert;
        }
        // 在vvVertices中删除包含这个节点的超边
        for (int i = 0; i < vVert.size(); i++)
        {
            vector<int> oldEdge = vvVertices[vVert[i]];
            vector<int> newEdge;
            for (int j = 0; j < oldEdge.size(); j++)
            {
                if (oldEdge[j] != edge)
                {
                    newEdge.push_back(oldEdge[j]);
                }
            }
            vvVertices[vVert[i]] = newEdge;
        }

    }
    return true;
}

/**
 * @brief 在超边中删除节点
 * 
 * @param 
 * @return true ：删除成功
 * @return false ：删除失败
 */
bool Hypergraph::deleteVertFromEdge(int e, vector<int> vecV)
{
    int edge = e;
    vector<int> vVert = vecV;
    if (edge >= edgeNum)
    {
        cout << "deleted edge is out of range" << endl;
        return false;
    }
    vector<int> oldVert = vvEdges[edge];    // 边edge原先拥有的节点
    if (oldVert.size() - vVert.size() < 0)
    {
        return false;
    }
    // 在vvEdges中删除超边中的节点
    unordered_set<int> usVert(oldVert.begin(), oldVert.end());
    for (int i = 0; i < vVert.size(); i++)
    {
        if (usVert.find(vVert[i]) == usVert.end())
        {
            return false;
        }
        usVert.erase(usVert.find(vVert[i]));
    }
    vector<int> newVert(usVert.begin(), usVert.end());
    // if (newVert.size() < 2)
    // {
    //     // 相当于这条超边已经不存在了
    //     vvEdges[edge].clear();
    //     vVert.insert(vVert.end(), newVert.begin(), newVert.end());
    // }
    // else
    // {
    //     vvEdges[edge] = newVert;
    // }
    vvEdges[edge] = newVert;
    // 在vvVertices中删除包含这个节点的超边
    for (int i = 0; i < vVert.size(); i++)
    {
        vector<int> oldEdge = vvVertices[vVert[i]];
        vector<int> newEdge;
        for (int j = 0; j < oldEdge.size(); j++)
        {
            if (oldEdge[j] != edge)
            {
                newEdge.push_back(oldEdge[j]);
            }
        }
        vvVertices[vVert[i]] = newEdge;
    }

    return true;
}

/**
 * @brief 向超边插入节点
 * 
 * @param e 待插入节点的超边
 * @param vecV 待插入的节点集
 * @return true 
 * @return false 
 */
bool Hypergraph::insertVertToEdge(int e, vector<int> vecV)
{
    // 修改vvEdges[e]，插入节点集
    vector<int> oldVert = vvEdges[e];    // 边e原先拥有的节点
    unordered_set<int> usVert(oldVert.begin(), oldVert.end());
    for (int i = 0; i < vecV.size(); i++)
    {
        if (usVert.find(vecV[i]) != usVert.end())
        {
            return false;
        }
        usVert.insert(vecV[i]);
    }
    vector<int> newVert(usVert.begin(), usVert.end());
    vvEdges[e] = newVert;
    // 在每个节点中添加边
    for (int i = 0; i < vecV.size(); i++)
    {
        vvVertices[vecV[i]].push_back(e);
    }
    return true;
}

void Hypergraph::deleteFunc(vector<int> root)
{
    for (int i = 0; i < root.size(); i++)
    {
        int v = root[i];
        int k = coreV[v];
        if (visited[v] == false)
        {
            visited[v] = true;
            mcd[v] = computeMcd(v);
            cd[v] = cd[v] + mcd[v];
        }
        if (removed[v] == false && cd[v] < k)
        {
            removed[v] = true;
            stack<int> stk;
            stk.push(v);
            while (!stk.empty())
            {
                int u = stk.top();
                stk.pop();
                vector<int> edgesofV = vvVertices[u];
                for (int j = 0; j < edgesofV.size(); j++)
                {
                    vector<int> vertofEdge = vvEdges[edgesofV[j]];
                    if ((findMinCore(vertofEdge) == k) && (eFlag[edgesofV[j]] == false))
                    {
                        eFlag[edgesofV[j]] = true;
                        for (int ij = 0; ij < vertofEdge.size(); ij++)
                        {
                            int w = vertofEdge[ij];
                            if (coreV[w] == k && w != u)
                            {
                                if (visited[w] == false)
                                {
                                    visited[w] = true;
                                    mcd[w] = computeMcd(w);
                                    cd[w] = cd[w] + mcd[w];
                                }
                                cd[w] = cd[w] - 1;
                                if (cd[w] < k && removed[w] == false)
                                {
                                    stk.push(w);
                                    removed[w] = true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return;
}

void Hypergraph::insertFunc(vector<int> root)
{
    for (int i = 0; i < root.size(); i++)
    {
        int v = root[i];
        if (visited[v] == true)
        {
            continue;
        }
        int k = coreV[v];
        visited[v] = true;
        mcd[v] = computeMcd(v);
        cd[v] = cd[v] + mcd[v];
        stack<int> stk1;
        stk1.push(v);
        while (!stk1.empty())
        {
            int u = stk1.top();
            stk1.pop();
            if (cd[u] > k)
            {
                vector<int> edgesofV = vvVertices[u];
                for (int j = 0; j < edgesofV.size(); j++)
                {
                    vector<int> vertofEdge = vvEdges[edgesofV[j]];
                    if (findMinCore(vertofEdge) == k)
                    {
                        for (int ij = 0; ij < vertofEdge.size(); ij++)
                        {
                            int w = vertofEdge[ij];
                            if (coreV[w] == k && w != u)
                            {
                                if (visited[w] == false)
                                {
                                    visited[w] = true;
                                    mcd[w] = computeMcd(w);
                                    cd[w] = cd[w] + mcd[w];
                                    stk1.push(w);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (removed[u] == false)
                {
                    stack<int> stk2;
                    stk2.push(u);
                    removed[u] = true;
                    while (!stk2.empty())
                    {
                        int x = stk2.top();
                        stk2.pop();
                        vector<int> edgesofX = vvVertices[x];
                        for (int j = 0; j < edgesofX.size(); j++)
                        {
                            vector<int> vertofEdge = vvEdges[edgesofX[j]];
                            if ((findMinCore(vertofEdge) == k) && (eFlag[edgesofX[j]] == false))
                            {
                                eFlag[edgesofX[j]] = true;
                                for (int ij = 0; ij < vertofEdge.size(); ij++)
                                {
                                    int y = vertofEdge[ij];
                                    if (coreV[y] == k && y != x)
                                    {
                                        cd[y] = cd[y] - 1;
                                        if (removed[y] == false && cd[y] == k)
                                        {
                                            removed[y] = true;
                                            stk2.push(y);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return;
}

bool Hypergraph::compare()
{
    //vector<int> staticCore = coreDecomp();
    if (staticCore.size() != coreV.size())
    {
        return false;
    }
    for (int i = 0; i < coreV.size(); i++)
    {
        if (staticCore[i] != coreV[i])
        {
            std::cout << i << '\t' << "staticCoreV: " << staticCore[i] << '\t' << "coreV: " << coreV[i] << std::endl;
            //return false;
        }
    }
    return true;
}


/**
 * @brief 根据更新边集构建由更新部分边集构成的超图
 * 
 * @param mpDeletedVert 
 */
void Hypergraph::constructNewGraph(unordered_map<int, vector<int>> mpDeletedVert)
{
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++)
    {
        int e = it->first;
        vector<int> vecV = vvEdges[e];
        mpEtoV[e] = vecV;
        for (int i = 0; i < vecV.size(); i++)
        {
            int v = vecV[i];
            if (mpVtoE.find(v) == mpVtoE.end())
            {
                vector<int> vecE;
                vecE.push_back(e);
                mpVtoE[v] = vecE;
            }
            else
            {
                mpVtoE[v].push_back(e);
            }
        }
    }
}

/**
 * @brief 给updated set中的边进行染色
 * 返回颜色数
 */
int Hypergraph::colorEdge(unordered_map<int, vector<int>> mpDeletedVert)
{
    constructNewGraph(mpDeletedVert);    // 构建新超图

    unordered_set<int> setA;    // 未被染色的边
    unordered_set<int> setB;    // 已经被染色的边
    unordered_map<int, bool> mpVisited;    // 标记updated set中边是否已经被访问
    unordered_map<int, int> mpEtoC;    // key是边，value是该边被染的颜色
    int maxColor = 1;
    for (auto it = mpEtoV.begin(); it != mpEtoV.end(); it++)
    {
        int e = it->first;
        setA.insert(e);
        mpVisited[e] = false;
    }

    while (!setA.empty())
    {
        int e = *(setA.begin());
        queue<int> qu;
        qu.push(e);
        mpVisited[e] = true;
        while (!qu.empty())
        {
            int r = qu.front();
            qu.pop();
            setA.erase(r);
            setB.insert(r);
            vector<int> vecV = mpEtoV[r];
            vector<int> vecColor;    // 邻边所染颜色
            for (int i = 0; i < vecV.size(); i++)
            {
                vector<int> vecE = mpVtoE[vecV[i]];
                for (int j = 0; j < vecE.size(); j++)
                {
                    int ee = vecE[j];
                    if (mpVisited[ee] == false)
                    {
                        qu.push(ee);
                        mpVisited[ee] = true;
                    }
                    if (mpEtoC.find(ee) != mpEtoC.end())
                    {
                        vecColor.push_back(mpEtoC[ee]);
                    }
                }
            }
            sort(vecColor.begin(), vecColor.end());
            int colorKind = 1;
            for (int i = 0; i < vecColor.size();)
            {
                if (vecColor[i] > colorKind)
                {
                    break;
                }
                else if (vecColor[i] == colorKind)
                {
                    colorKind += 1;
                    i++;
                }
                else
                {
                    i++;
                }
            }
            mpEtoC[r] = colorKind;
            if (mpCtoE.find(colorKind) == mpCtoE.end())
            {
                vector<int> vecTmp;
                vecTmp.push_back(r);
                mpCtoE[colorKind] = vecTmp;
            }
            else
            {
                mpCtoE[colorKind].push_back(r);
            }
            maxColor = (maxColor > colorKind) ? maxColor : colorKind;
        }
    }
    
    // 
    return maxColor;

}

/**
 * @brief 并行删除
 * 
 * @param threadNum 线程数
 * @param curColor 染的颜色
 */
void Hypergraph::paraDeletion(int threadNum, int curColor, unordered_map<int, vector<int>> mpDeletedVert)
{
    // 将相关参数初始化
    init();
    // 从原图的指定超边中删除指定节点，并构建deleteFunc的根节点集
    vector<int> vecColoredEdges = mpCtoE[curColor];
    unordered_map<int, vector<int>> rootD;    // deleteFunc的根节点
    for (int i = 0; i < vecColoredEdges.size(); i++)
    {
        int edge = vecColoredEdges[i];
        vector<int> vVert = mpDeletedVert[edge];
        if (deleteVertFromEdge(edge, vVert) == false)
        {
            cout << edge << " paraDeletion delete error" << endl;
            return;
        }
        // vVert = vvEdges[edge];
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        vector<int> vecVmin2 = findMinVertices(vvEdges[edge]);
        int kmin2 = findMinCore(vvEdges[edge]);
        kmin2 = (kmin2 < 0) ? kmin : kmin2;
        if (kmin > kmin2)
        {
            ;
        }
        else if (kmin == kmin2)
        {
            if (rootD.find(kmin) == rootD.end())
            {
                rootD[kmin] = vecVmin;
            }
            else
            {
                rootD[kmin].insert(rootD[kmin].end(), vecVmin.begin(), vecVmin.end());
            }
        }
        else
        {
            if (rootD.find(kmin) == rootD.end())
            {
                rootD[kmin] = vecVmin;
            }
            else
            {
                rootD[kmin].insert(rootD[kmin].end(), vecVmin.begin(), vecVmin.end());
            }
        }
    }

    // // 统计每个核值下有多少根节点
    // unordered_map<int, int> mpTmp;
    // for (auto it = rootD.begin(); it != rootD.end(); it++)
    // {
    //     mpTmp[it->first] = (it->second).size();
    // }
    // kKindD.push_back(mpTmp);

    // 核值减少情况
    ThreadPool pool(threadNum);
    vector<future<void>> futures;
    for (auto it = rootD.begin(); it != rootD.end(); it++)
    {
        futures.emplace_back(pool.enqueue(&Hypergraph::deleteFunc, this, (it->second)));
    }
    for (auto &f: futures)
    {
        f.get();
    }
    delCores();


    // 将相关参数初始化
    init();
    // 构建insertFunc的根节点集
    vecColoredEdges = mpCtoE[curColor];
    unordered_map<int, vector<int>> rootI;    // deleteFunc的根节点
    for (int i = 0; i < vecColoredEdges.size(); i++)
    {
        int edge = vecColoredEdges[i];
        vector<int> vVert = vvEdges[edge];
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        if (rootI.find(kmin) == rootI.end())
        {
            rootI[kmin] = vecVmin;
        }
        else
        {
            rootI[kmin].insert(rootI[kmin].end(), vecVmin.begin(), vecVmin.end());
        }
    }
    futures.clear();
    for (auto it = rootI.begin(); it != rootI.end(); it++)
    {
        futures.emplace_back(pool.enqueue(&Hypergraph::insertFunc, this, (it->second)));
    }
    for (auto &f: futures)
    {
        f.get();
    }
    insCores();
}

/**
 * @brief 
 * 
 * @param threadNum 
 * @param curColor 
 */
void Hypergraph::paraInsertion(int threadNum, int curColor, unordered_map<int, vector<int>> mpDeletedVert)
{
    // 将相关参数初始化
    init();
    vector<int> vecColoredEdges = mpCtoE[curColor];
    unordered_map<int, vector<int>> rootD;    // deleteFunc的根节点
    for (int i = 0; i < vecColoredEdges.size(); i++)
    {
        int edge = vecColoredEdges[i];
        vector<int> vVert = vvEdges[edge];
        // vVert = vvEdges[edge];
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        if (insertVertToEdge(edge, mpDeletedVert[edge]) == false)
        {
            cout << edge << " paraDeletion insert error" << endl;
            return;
        }
        if (rootD.find(kmin) == rootD.end())
        {
            rootD[kmin] = vecVmin;
        }
        else
        {
            rootD[kmin].insert(rootD[kmin].end(), vecVmin.begin(), vecVmin.end());
        }
    }

    // // 统计每个核值下有多少根节点
    // unordered_map<int, int> mpTmp;
    // for (auto it = rootD.begin(); it != rootD.end(); it++)
    // {
    //     mpTmp[it->first] = (it->second).size();
    // }
    // kKindI.push_back(mpTmp);

    // 核值减少情况
    ThreadPool pool(threadNum);
    vector<future<void>> futures;
    for (auto it = rootD.begin(); it != rootD.end(); it++)
    {
        futures.emplace_back(pool.enqueue(&Hypergraph::deleteFunc, this, (it->second)));
    }
    for (auto &f: futures)
    {
        f.get();
    }
    delCores();

    // 将相关参数初始化
    init();
    // 构建insertFunc的根节点集
    vecColoredEdges = mpCtoE[curColor];
    unordered_map<int, vector<int>> rootI;    
    for (int i = 0; i < vecColoredEdges.size(); i++)
    {
        int edge = vecColoredEdges[i];
        vector<int> vVert = vvEdges[edge];
        vector<int> vecVmin = findMinVertices(vVert);
        int kmin = findMinCore(vVert);
        if (rootI.find(kmin) == rootI.end())
        {
            rootI[kmin] = vecVmin;
        }
        else
        {
            rootI[kmin].insert(rootI[kmin].end(), vecVmin.begin(), vecVmin.end());
        }
    }
    futures.clear();
    for (auto it = rootI.begin(); it != rootI.end(); it++)
    {
        futures.emplace_back(pool.enqueue(&Hypergraph::insertFunc, this, (it->second)));
    }
    for (auto &f: futures)
    {
        f.get();
    }
    insCores();
}


/**
 * @brief 将受影响的节点核值-1
 * 
 */
void Hypergraph::delCores()
{
    for (int i = 0; i < vertexNum; i++)
    {
        if (visited[i] == true && removed[i] == true)
        {
            coreV[i] = coreV[i] - 1;
        }
    }
}

void Hypergraph::insCores()
{
    for (int i = 0; i < vertexNum; i++)
    {
        if (visited[i] == true && removed[i] == false)
        {
            coreV[i] = coreV[i] + 1;
        }
    }
}
