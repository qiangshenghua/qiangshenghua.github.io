#ifndef HYPERGRAPH_H_INCLUDED
#define HYPERGRAPH_H_INCLUDED
# include <iostream>
# include <vector>
# include <unordered_set>
# include <unordered_map>
# include <stack>
# include <queue>
# include <algorithm>
# include "threadpool.h"

using namespace std;

class Hypergraph {
public:
    int edgeNum;    // 超边数
    int vertexNum;    // 节点数
    vector<vector<int>> vvVertices;    // vvVertices[i]表示节点i所属的超边的集合
    vector<vector<int>> vvEdges;    // vvEdges[i]表示超边i所包含的节点集合
    vector<bool> visited;
    vector<bool> removed;
    vector<bool> eFlag;
    vector<int> mcd;
    vector<int> cd;
    vector<int> degree;
    vector<int> coreV;
    vector<int> coreE;
    vector<int> staticCore;
    vector<unordered_map<int, int>> kKindD;
    vector<unordered_map<int, int>> kKindI;

    // 对于updated set来说
    unordered_map<int, vector<int>> mpCtoE;    // key是颜色，value是边

    Hypergraph() {edgeNum = 0; vertexNum = 0;}
    ~Hypergraph() {}

    void addEdge(vector<int> edge);
    void init();
    // 核值分解，将计算出的核值返回
    vector<int> coreDecomp();
    // 处理超边中节点删除的情况，key是超边，value是该超边中被删除的节点
    void vertDeletion(unordered_map<int, vector<int>> mpDeletedVert);
    bool deleteVertFromEdge(unordered_map<int, vector<int>> mpDeletedVert);
    bool deleteVertFromEdge(int e, vector<int> vecV);
    void deleteFunc(vector<int> root);
    void vertInsertion(unordered_map<int, vector<int>> mpDeletedVert);
    bool insertVertToEdge(int e, vector<int> vecV);
    void insertFunc(vector<int> root);
    bool compare();
    int colorEdge(unordered_map<int, vector<int>> mpDeletedVert);    // 染色构建matching，返回颜色数
    void paraDeletion(int threadNum, int curColor, unordered_map<int, vector<int>> mpDeletedVert);    // 并行删除入口
    void paraInsertion(int threadNum, int curColor, unordered_map<int, vector<int>> mpDeletedVert);    // 并行插入入口


private:
    unordered_map<int, vector<int>> mpVtoE;    // key是节点，value是边，包含了该节点的所有边
    unordered_map<int, vector<int>> mpEtoV;    // key是边，value是节点，该边包含的所有节点

    vector<int> findMinVertices(vector<int> vVertices);
    int findMinCore(vector<int> vVertices);
    int computeMcd(int v);
    void constructNewGraph(unordered_map<int, vector<int>> mpDeletedVert);
    void delCores();
    void insCores();
};

#endif // HYPERGRAPH_H_INCLUDED
