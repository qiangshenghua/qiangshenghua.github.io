# Parallel core maintainance on Dynamic Hypergraphs
ParallelDynamicHypergraph and DynamicHypergraph include the algorithms that maintain core numbers in a parallel and sequential way, respectively. ScalableHypergraph includes the parallel static and GPC algorithms we implement according to the following work:"K. Gabert, A. Pinar, and U. V. Catalyurek, Shared-memory scalable k-core maintenance on dynamic graphs and hypergraphs,IEEE International Parallel and Distributed Processing Symposium Workshops, pp. 998-1007, 2021." 

# How To Use

```shell
$ cd DynamicHypergraph 
$ make
$ ./main -c(sequential)/-l(LYCLC)/-s(static) graph_filename edge_filename threadnum
$ # cd ParallelDynamicHypergraph
$ # make
$ # ./main -p(parallel) graph_filename edge_filename threadnum
$ # cd scalableHypergraph
$ # make
$ # ./main -sp(parallel static)/g(GPC) graph_filename edge_filename threadnum
```

The graph file is supposed to be in the format of edge file and the vertices are number from 0, see the examplegraph.

# Example

```shell
$ cd ParallelDynamicHypergraph
$ ./main -p ../examplegraph.txt ../examplegraph_100.txt 8
```