# include <iostream>
# include <fstream>
# include <string.h>
# include <stdlib.h>
# include <vector>
# include <unordered_map>
# include <algorithm>
//# include "scalableHypergraph.h"
//# include "threadpool.h"

using namespace std;

vector<int> splitStr(string strInput, string strSpt);

int main(int argc, char *argv[])
{

    string graphFile = argv[1];
    string edgeFile = argv[2];
    int updatedNum = atoi(argv[3]);

    ifstream finGraph(graphFile.data());
    ofstream geneEdge(edgeFile.data());
    if (!finGraph) {
        cout << "Error opening " << graphFile << " for input" << endl;
        return 0;
    }
    // 更新图文件
    if (!geneEdge) {
        cout << "Error creating " << edgeFile << " for input" << endl;
        return 0;
    }

    // ScalableHypergraph hypergraph;
    // 按行读取原图文件 每行一条超边内的节点编号
    string edgeLine;
    string strSpt = "\t";
    // while (getline(finGraph, edgeLine)) {
    //     vector<int> input = splitStr(edgeLine, strSpt);
    //     hypergraph.addEdge(input);
    // }

    unordered_map<int, vector<int>> mpDeletedVert;
    vector<int> key;  // map 中的各 key
    int pinTotal = 0;
    vector<int> pinNum;
    while (getline(finGraph, edgeLine)) {
        //第一个数字边序号, 后面操作节点编号
        vector<int> input = splitStr(edgeLine, strSpt);
        int e = input[0];
        vector<int> vs;
        vs.assign(input.begin()+1, input.end());
        mpDeletedVert[e] = vs;
        key.push_back(e);
        pinTotal += vs.size();
        pinNum.push_back(pinTotal);
    }

    
    // int pinTotal = 0;
    // vector<int> pinNum;
    // for (auto iter : hypergraph.vvEdges) {
    //     pinTotal += iter.size();
    //     pinNum.push_back(pinTotal);
    // }
    srand(updatedNum);
    int random = 0;
    int randEdgeIndex = 0, randVertIndex = 0, randEdge = 0, randVert = 0;
    unordered_map<int, vector<int>> mpUpdatedVert;
    for (int i = updatedNum; i > 0; ) {
        // randEdgeIndex = rand() % key.size();
        // randEdge = key[randEdgeIndex];
        // randVertIndex = rand() % mpDeletedVert[randEdge].size();
        // randVert = mpDeletedVert[randEdge][randVertIndex];
        
        for (randEdgeIndex = 0, random = rand() % pinTotal; randEdgeIndex < pinNum.size() && random > pinNum[randEdgeIndex]-1; randEdgeIndex++);
        if (randEdgeIndex > 0) {
            randEdge = key[randEdgeIndex];
            //randVert = hypergraph.vvEdges[randEdge][random - pinNum[randEdge-1]];
            randVert = mpDeletedVert[randEdge][random - pinNum[randEdgeIndex-1]];
        }
        else{
            randEdge = key[randEdgeIndex];
            randVert = mpDeletedVert[randEdge][random];
        }
            
        if (mpUpdatedVert.find(randEdge) != mpUpdatedVert.end()) {
            if (find(mpUpdatedVert[randEdge].begin(), mpUpdatedVert[randEdge].end(), randVert) == mpUpdatedVert[randEdge].end()) {
                mpUpdatedVert[randEdge].push_back(randVert);
                i--;
            }
        }
        else {
            mpUpdatedVert.insert(unordered_map<int, vector<int>>::value_type(randEdge, vector<int>(0)));
            mpUpdatedVert[randEdge].push_back(randVert);
            i--;
        }
    }

    for (auto iter : mpUpdatedVert) {
        string output = "";
        output += to_string(iter.first);
        for (auto it : iter.second) {
            output += "\t";
            output += to_string(it);
        }
        output += "\n";
        geneEdge << output;
    }



    finGraph.close();
    geneEdge.close();
    return 0;
}

// 将输入的字符串分割
vector<int> splitStr(string strInput, string strSpt)
{
    // 用strSpt分割strInput
    vector<string> vecStr;
    while (strInput.find(strSpt) != strInput.npos)
    {
        size_t pos = strInput.find(strSpt);
        string str2 = strInput.substr(0, pos);
        vecStr.push_back(str2);
        strInput = strInput.substr(pos+strSpt.size());
    }
    vecStr.push_back(strInput);
    // 将vector<string>转成vector<int>
    vector<int> vecInt;
    for (int i = 0; i < vecStr.size(); i++)
    {
        string strTmp = vecStr[i];
        vecInt.push_back(atoi(strTmp.c_str()));
    }
    return vecInt;
}