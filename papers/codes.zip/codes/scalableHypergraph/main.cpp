#include <fstream>
#include <sys/time.h>
#include <string.h>
#include "scalableHypergraph.h"
#include "threadpool.h"

using namespace std;

vector<int> splitStr(string strInput, string strSpt);

int main(int argc, char *argv[])
{
    // Hypergraph hypergraph;
    // vector<int> a0 = {0, 1, 2};
    // vector<int> a1 = {0, 3, 4};
    // vector<int> a2 = {0, 3, 5};
    // vector<int> a3 = {0, 4, 5};
    // vector<int> a4 = {3, 4, 5};
    // vector<int> a5 = {1, 3, 4};
    // vector<int> a6 = {4, 5};
    // hypergraph.addEdge(a0);
    // hypergraph.addEdge(a1);
    // hypergraph.addEdge(a2);
    // hypergraph.addEdge(a3);
    // hypergraph.addEdge(a4);
    // hypergraph.addEdge(a5);
    // hypergraph.addEdge(a6);

    // hypergraph.coreV = hypergraph.coreDecomp();

    // vector<int> vecD = {1};
    // unordered_map<int, vector<int>> unMap;
    // unMap[6] = vecD;

    // hypergraph.vertInsertion(unMap);
    // cout << hypergraph.compare() << endl;

    if (argc < 5)
    {
        cout << "Usage: -sp(parallel static)/-g(GPC)/ graph_filename edge_filename threadnum" << endl;
        return 0;
    }

    string graphFile = argv[2];
    string edgeFile = argv[3];
    int threadNum = atoi(argv[4]);

    ifstream finGraph(graphFile.data());
    ifstream finEdge(edgeFile.data());
    if (!finGraph)
    {
        cout << "Error opening " << graphFile << " for input" << endl;
        return 0;
    }
    ScalableHypergraph hypergraph;
    // 按行读取原图文件 每行一条超边内的节点编号
    string edgeLine;
    string strSpt = "\t";
    while (getline(finGraph, edgeLine))
    {
        vector<int> input = splitStr(edgeLine, strSpt);
        hypergraph.addEdge(input);
    }
    // 设置线程数
    hypergraph.setThreadNum(threadNum);

    // 按行读取更新图文件
    if (!finEdge)
    {
        cout << "Error opening " << edgeFile << " for input" << endl;
        return 0;
    }
    unordered_map<int, vector<int>> mpDeletedVert;
    vector<batch> batchset;
    bool IorD = false; // 先删除后添加, insert: true delete: false
    // int flag = 0;
    while (getline(finEdge, edgeLine))
    {
        // 第一个数字边序号, 后面操作节点编号
        vector<int> input = splitStr(edgeLine, strSpt);
        int e = input[0];
        vector<int> vs;
        vs.assign(input.begin() + 1, input.end());
        mpDeletedVert[e] = vs;
        // if (flag >= 50)
        // {
        //     mpDeletedVert[e] = vs;
        // }
        // flag += 1;
    }

    struct timeval t_start, t_end, f_start, f_end;
    // 静态分解
    hypergraph.statichhcLocal();

    // if (strcmp(argv[1], "-c") == 0)
    // {
    //     gettimeofday(&t_start, NULL);
    //     hypergraph.vertDeletion(mpDeletedVert);
    //     gettimeofday(&t_end, NULL);
    //     double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000000 + (t_end.tv_usec - t_start.tv_usec);
    //     std::cout << "Delete" << '\t' << del_t << std::endl;

    //     gettimeofday(&t_start, NULL);
    //     hypergraph.vertInsertion(mpDeletedVert);
    //     gettimeofday(&t_end, NULL);
    //     double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000000 + (t_end.tv_usec - t_start.tv_usec);
    //     std::cout << "Insert" << '\t' << ins_t << std::endl;
    // }

    // 并行算法核值维护
    // if (strcmp(argv[1], "-p") == 0)
    // {
    //     gettimeofday(&t_start, NULL);
    //     int maxColor = hypergraph.colorEdge(mpDeletedVert);
    //     gettimeofday(&t_end, NULL);
    //     double colorTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
    //     // cout << "colorTime" << '\t' << colorTime << endl;
    //     // cout << "MaxColor" << '\t' << maxColor << endl;

    //     gettimeofday(&t_start, NULL);
    //     int curColor = 1;
    //     while (curColor <= maxColor)
    //     {
    //         hypergraph.paraDeletion(threadNum, curColor, mpDeletedVert);
    //         curColor += 1;
    //     }
    //     gettimeofday(&t_end, NULL);
    //     double del_t = colorTime + (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
    //     std::cout << "Delete" << '\t' << del_t << std::endl;

    //     gettimeofday(&t_start, NULL);
    //     curColor = 1;
    //     while (curColor <= maxColor)
    //     {
    //         hypergraph.paraInsertion(threadNum, curColor, mpDeletedVert);
    //         curColor += 1;
    //     }
    //     gettimeofday(&t_end, NULL);
    //     double ins_t = colorTime + (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
    //     std::cout << "Insert" << '\t' << ins_t << std::endl;

    //     // for (int i = 0; i < hypergraph.kKindD.size(); i++)
    //     // {
    //     //     unordered_map<int, int> mpTmp = hypergraph.kKindD[i];
    //     //     for (auto it = mpTmp.begin(); it != mpTmp.end(); it++)
    //     //     {
    //     //         cout << "k: " << it->first << "\t" << it->second << endl;
    //     //     }
    //     //     cout << endl;
    //     // }
    // }

    if (strcmp(argv[1], "-g") == 0)
    {

        IorD = false;
        hypergraph.mapToBatch(mpDeletedVert, batchset, IorD);
        gettimeofday(&t_start, NULL);
        // std::cout << "mod algorithm delete begins" << std::endl;
        hypergraph.mod(mpDeletedVert, batchset, IorD);
        gettimeofday(&t_end, NULL);
        double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Delete" << '\t' << del_t << std::endl;

        IorD = true;
        hypergraph.changeBatch(batchset, IorD);
        gettimeofday(&t_start, NULL);
        // std::cout << "mod algorithm insert begins" << std::endl;
        hypergraph.mod(mpDeletedVert, batchset, IorD);
        gettimeofday(&t_end, NULL);
        double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Insert" << '\t' << ins_t << std::endl;
    }
    else if (strcmp(argv[1], "-s") == 0)
    {

        IorD = false;
        hypergraph.mapToBatch(mpDeletedVert, batchset, IorD);
        gettimeofday(&t_start, NULL);
        // std::cout << "set algorithm delete begins" << std::endl;
        hypergraph.set(mpDeletedVert, batchset, IorD);
        gettimeofday(&t_end, NULL);
        double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Delete" << '\t' << del_t << std::endl;

        IorD = true;
        hypergraph.changeBatch(batchset, IorD);
        gettimeofday(&t_start, NULL);
        // std::cout << "set algorithm insert begins" << std::endl;
        hypergraph.set(mpDeletedVert, batchset, IorD);
        gettimeofday(&t_end, NULL);
        double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Insert" << '\t' << ins_t << std::endl;
    }
    else if (strcmp(argv[1], "-sp") == 0)
    {

        IorD = false;
        gettimeofday(&t_start, NULL);
        if (IorD)
            hypergraph.vertInsertion(mpDeletedVert);
        else
            hypergraph.vertDeletion(mpDeletedVert);
        // std::cout << "static algorithm delete begins" << std::endl;
        hypergraph.statichhcLocal();
        gettimeofday(&t_end, NULL);
        double del_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Delete" << '\t' << del_t << std::endl;

        IorD = true;
        gettimeofday(&t_start, NULL);
        if (IorD)
            hypergraph.vertInsertion(mpDeletedVert);
        else
            hypergraph.vertDeletion(mpDeletedVert);
        // std::cout << "set algorithm insert begins" << std::endl;
        hypergraph.statichhcLocal();
        gettimeofday(&t_end, NULL);
        double ins_t = (t_end.tv_sec - t_start.tv_sec) * 1000.0 + (t_end.tv_usec - t_start.tv_usec) / 1000.0;
        std::cout << "Insert" << '\t' << ins_t << std::endl;
    }
    else
    {
        cout << "wrong params!" << endl;
    }

    // vector<int> test = {15314,1541,24258,184165,291394,55675,31160,104414,199587,23637,80644,258852,37758,78018,77155};
    // for (int i = 0; i < test.size(); i++) {
    //     if (i < hypergraph.staticCoreV.size())
    //         std::cout << test[i] << '\t' << "staticCoreV:" << hypergraph.staticCoreV[test[i]] << '\t' << "coreV:" << hypergraph.coreV[test[i]] << std::endl;
    // }
    // for (int i = 0; i < hypergraph.staticCoreV.size(); i++) {
    //     if (i < hypergraph.staticCoreV.size())
    //         std::cout << i << '\t' << "staticCoreV:" << hypergraph.staticCoreV[i] << '\t' << "coreV:" << hypergraph.coreV[i] << std::endl;
    // }

    // mpDeletedVert.clear();
    // mpDeletedVert[62723] = {60};
    // hypergraph.vertDeletion(mpDeletedVert);
    // cout << hypergraph.compare() << endl;
    // hypergraph.vertInsertion(mpDeletedVert);
    // cout << hypergraph.compare() << endl;

    finGraph.close();
    finEdge.close();
    return 0;
}

// 将输入的字符串分割
vector<int> splitStr(string strInput, string strSpt)
{
    // 用strSpt分割strInput
    vector<string> vecStr;
    while (strInput.find(strSpt) != strInput.npos)
    {
        size_t pos = strInput.find(strSpt);
        string str2 = strInput.substr(0, pos);
        vecStr.push_back(str2);
        strInput = strInput.substr(pos + strSpt.size());
    }
    vecStr.push_back(strInput);
    // 将vector<string>转成vector<int>
    vector<int> vecInt;
    for (int i = 0; i < vecStr.size(); i++)
    {
        string strTmp = vecStr[i];
        vecInt.push_back(atoi(strTmp.c_str()));
    }
    return vecInt;
}