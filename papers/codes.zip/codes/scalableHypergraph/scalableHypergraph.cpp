#include "scalableHypergraph.h"

/**
 * the maximum integer such that there exist at least y elements in (x1, x2, …, xn), each of which is no less than y.
 */
int ScalableHypergraph :: HIndex(vector<int> &L) {

    sort(L.begin(), L.end());       // 升序排列
    reverse(L.begin(), L.end());    // 改为降序
    
    int h_index = L.size();
    while (h_index >= 1) {
        if (L[h_index-1] >= h_index)
            break;
        else
            h_index--;
    }

    return h_index;
}


/**
 * Algorithm 2 init core value
 * if τ is not given then ∀ v ∈ V , τ[v] ← deg(v); if A is not given then A ← V
 */
void ScalableHypergraph :: statichhcLocal() {
    // 运行时不动态调整线程数
    omp_set_dynamic(0);
    omp_set_num_threads(threadNum);

    // 用 V 初始化 A(frontier)
    // vector<int> frontier;
    // for (int i = 0; i < vertexNum; i++) {
    //     frontier.push_back(i);
    // }
    frontier.clear();
    frontier.resize(vertexNum, true);

    /**
     * 用 deg(v) 初始化 coreV
     * deg(v) = |Γ(v)| = |{u ∈ V : ∃e ∈ E, {u, v} ⊆ e}|
     */
    //std::cout << "init vertexNum:" << '\t' << vertexNum << std::endl;
    coreV.resize(vertexNum, 0);
    #pragma omp parallel for
    for (int vertex = 0; vertex < vertexNum; vertex++) {
        coreV[vertex] = vvVertices[vertex].size();
        // vector<int> tempneighbor;
        // for (auto edge : vvVertices[vertex]) {
        //     for (auto neighbor : vvEdges[edge]) {
        //         // if ((neighbor != vertex) && (find(tempneighbor.begin(), tempneighbor.end(), neighbor) == tempneighbor.end()))
        //         if ((neighbor != vertex))
        //             tempneighbor.push_back(neighbor);
        //     }
        // }
        // coreV[vertex] = tempneighbor.size();
        // // std::cout << vertex << "\t" << "degree" << "\t" << coreV[vertex]  << std::endl;
    }

    std::cout << "static hhcLocal begins" << std::endl;
    //hhcLocal();
    paraCoreDec();

    // 记录静态分解结果
    staticCoreV.clear();
    staticCoreV.assign(coreV.begin(), coreV.end());
    // for (auto val : coreV) {
    //     staticCoreV.push_back(val);
    // }
    // staticCoreV = coreDecomp();
    // compare();
}
/**
 * Algorithm 2
 * Data: hypergraph H = (V, E)
 * Input: frontier A, optional τ initialization
 */
void ScalableHypergraph :: hhcLocal() {
    // 运行时不动态调整线程数
    omp_set_dynamic(0);
    omp_set_num_threads(threadNum);

    /**
     * 判断是否 converge (收敛), frontier 中有为 false 的则不收敛
     */
    volatile bool converge = true;
    for (int i = 0; converge && (i < frontier.size()); i++) {
        converge = converge && frontier[i];
    }

    while (!converge) {
        // vector<int> updated_frontier;
        // 记录上一轮中核值与被标记待收敛的节点
        vector<int> tempcoreV(coreV);
        vector<bool> tempFrontier(frontier);

        // 默认会全部收敛, 发现核值不同则后续中更改
        converge = true;
        frontier.clear();
        frontier.resize(vertexNum, true);
    
        // std::cout << "A hhcLocalParallel round begins" << std::endl;
        // 并行 v ∈ A(frontier);
        // ThreadPool pool(threadNum);
        // vector<future<void>> futures;
        // for (auto vertex : tempFrontierV) {
        //     futures.emplace_back(pool.enqueue(&ScalableHypergraph::hhcLocalParallel, this, vertex, updated_frontier, tempcoreV));
        // }
        // for (auto &f: futures) {
        //     f.get();
        // }

        // @brief hhcLocalPara()
        #pragma omp parallel for
        for (int vertex = 0; vertex < tempFrontier.size(); vertex++) {
            //int vertex = tempFrontier[i];
            if(tempFrontier[vertex])
                continue;

            vector<int> extend_neighbor;
            for (auto edge : vvVertices[vertex]) {
                // 有除了vertex 以外的节点(邻居)
                // if (vvEdges[edge].size() > 1) {
                    // std::cout << vertex << "\t" << "on edge " << edge << std::endl;
                    // for (auto neighbor : vvEdges[edge]) {
                    //     std::cout << neighbor << '\t' << coreV[neighbor] << std::endl;
                    // }
                    int min_val = INFINITE;
                    for (auto neighbor : vvEdges[edge]) {
                        // if (neighbor != vertex) {
                        min_val = min(min_val, tempcoreV[neighbor]);
                        // }
                    }
                    //std::cout << vertex  << " on edge " << edge << '\t' << "neighbor: " << min_val << std::endl;
                    extend_neighbor.push_back(min_val);
                // }
            }
            int h_index = HIndex(extend_neighbor);
            //std::cout << vertex << "\t" << "h_index: " << h_index << std::endl;

            if (h_index != tempcoreV[vertex]) {
                coreV[vertex] = h_index;
                frontier[vertex] = false;
                //updated_frontier.push_back(vertex);
                // updated_frontier.extend(vertex_neighbor)
                for (auto edge : vvVertices[vertex]) {
                    for (auto neighbor : vvEdges[edge]) {
                        if (neighbor != vertex) {
                            frontier[neighbor] = false;
                            //std::cout << neighbor << "\t" << "become false" << std::endl;
                            //updated_frontier.push_back(neighbor);
                        }
                    }
                }
            }
            else
                coreV[vertex] = h_index;
        }

        /**
         * 判断是否 converge (收敛), frontier 中有为 false 则不收敛
         */
        for (int i = 0; converge && (i < frontier.size()); i++) {
            converge = converge && frontier[i];
        }

        // 去重
        //sort(updated_frontier.begin(),updated_frontier.end());
        //updated_frontier.erase(unique(updated_frontier.begin(), updated_frontier.end()), updated_frontier.end());
        //std::cout << "updated_frontier size:" << '\t' << updated_frontier.size() << std::endl;

        // 活跃节点更新 frontier = updated_frontier
        // 核值更新 local_val = updated_local_val(串行必须最后更改)
        // swap(frontier, updated_frontier);
        //frontier.resize(updated_frontier.size());
        //frontier.assign(updated_frontier.begin(), updated_frontier.end());
        // swap(local_val, updated_local_val);
        // coreV.assign(updated_local_val.begin(), updated_local_val.end());
        //std::cout << "A hhcLocalParallel round ends" << std::endl;
    }

    return;
}
/**
 * Algorithm 2 Parallel Part
 */
void ScalableHypergraph :: hhcLocalParallel(int vertex, vector<int> &updated_frontier, vector<int> &tempcoreV) {
    vector<int> extend_neighbor;

    for (auto edge : vvVertices[vertex]) {
        // 有除了vertex 以外的节点(邻居)
        //if (vvEdges[edge].size() > 1) {
            int min_val = INFINITE;
            for (auto neighbor : vvEdges[edge]) {
                //if (neighbor != vertex) {
                    min_val = min(min_val, tempcoreV[neighbor]);
                //}
            }
            extend_neighbor.push_back(min_val);
        //}
    }

    int h_index = HIndex(extend_neighbor);
    if (h_index != tempcoreV[vertex]) {
        coreV[vertex] = h_index;
        updated_frontier.push_back(vertex);
        std::cout << "push_back " << vertex << std::endl;
        // updated_frontier.extend(vertex_neighbor)
        for (auto edge : vvVertices[vertex]) {
            for (auto neighbor : vvEdges[edge]) {
                if (neighbor != vertex) {
                    updated_frontier.push_back(neighbor);
                    std::cout << "push_back " << neighbor << std::endl;
                }
            }
        }
        // 去重
        // sort(updated_frontier.begin(),updated_frontier.end());
        // updated_frontier.erase(unique(updated_frontier.begin(), updated_frontier.end()), updated_frontier.end());
    }
    else
        coreV[vertex] = h_index;
    std::cout << vertex << '\t' << "updated_frontier size:" << '\t' << updated_frontier.size() << std::endl;
}

/**
 * Algorithm 4 intit
 * Input: batch edge set B
 */
void ScalableHypergraph :: fmod(vector<batch> &batchset, vector<int> &incNum, vector<int> &delNum) {
    /**
     * pin.first.first: edge
     * pin.first.second: vertex
     * pin.second: c: ture - insert / false - delete
     */
    //std::cout << "fmod begins" << std::endl;
    for (auto pin : batchset) {
        //std::cout << pin.first.first << '\t' << pin.first.second << std::endl;
        bool minflag = true;
        for (auto vertex : vvEdges[pin.first.first]) {
            if (coreV[vertex] < coreV[pin.first.second]) {
                minflag = false;
                break;
            }
        }
        if (minflag) {
            if(pin.second)
                incNum[coreV[pin.first.second]] += 1;
            else
                delNum[coreV[pin.first.second]] += 1;
        }
    }
    //std::cout << "batchset size:"<< '\t' << batchset.size() << std::endl;

}
/**
 * Algorithm 4: The mod algorithm
 * Data: hypergraph H = (V, E), local values τ
 * Input: batch edge set B
 * @param IorD insert-true delete-false
 */
void ScalableHypergraph :: mod(unordered_map<int, vector<int>> &mpVert, vector<batch> &batchset, bool IorD) {
    // 运行时不动态调整线程数
    omp_set_dynamic(0);
    omp_set_num_threads(threadNum);

    /**
     * unordered_map<int, int> incNum;
     * unordered_map<int, int> delNum;
     * unordered_map<int, int> rsvNum;
     * incNum的map内元素个数为核值种类, 为方便直接用vector, 上界vertexNum
     */
    vector<int> incNum(vertexNum, 0);
    vector<int> delNum(vertexNum, 0);
    vector<int> rsvNum(vertexNum, 0);

    /**
     * @brief 先插入删除节点，利用batch edge set B初始化 maintainH(f-mod, B)
     */
    if (IorD)
        vertInsertion(mpVert);
    else
        vertDeletion(mpVert);
    fmod(batchset, incNum, delNum);

    // if (IorD) {
    //     for (int i = 0; i < incNum.size(); i++) {
    //         if (incNum[i] != 0)
    //             std::cout << "incNum " << i << '\t' << incNum[i] << std::endl;
    //     }
    // }
    // else {
    //     for (int i = 0; i < delNum.size(); i++) {
    //         if (delNum[i] != 0)
    //             std::cout << "delNum " << i << '\t' << delNum[i] << std::endl;
    //     }
    // }

    // std::cout << "modParallel begins" << std::endl;
    // 并行 key ∈ keys(I);
    // ThreadPool pool(threadNum);
    // vector<future<void>> futures;
    // for (int key = 0; key < incNum.size(); key++) {
    //     futures.emplace_back(pool.enqueue(&ScalableHypergraph::modParallel, this, key, incNum, delNum, rsvNum));
    // }
    // for (auto &f: futures) {
    //     f.get();
    // }

    // @brief modParallel
    if (IorD) {
        // 插入的情况
        //#pragma omp parallel for
        //vector<int> rsvNumTemp(vertexNum, 0);
        for (int key = 0; key < incNum.size(); key++) {
            if (incNum[key] == 0)
                continue;
            
            // 开启计数
            // if(rsvNum[key] == -1)
            //     rsvNum[key] = 0;
            
            // 并行取max
            // if (key-1 >= 0) {
            //     for (int t = max(key-delNum[key], 0); t <= key-1; t++) {
            //         // if(rsvNum[t] == -1)
            //         //     rsvNum[t] = 0;
            //         rsvNum[t] += incNum[key];
            //         rsvNum[key] += incNum[t];
            //     }
            // }
        
            // 为求上界取最大
            rsvNum[key] = max(rsvNum[key], incNum[key]);

            if (key+1 < incNum.size()) {
                for (int t = key+1; t < incNum.size() && t <= key+incNum[key]; t++) {
                    // if(rsvNum[t] == -1)
                    //     rsvNum[t] = 0;
                    rsvNum[t] = rsvNum[t] + key + incNum[key] - t;
                    rsvNum[key] += incNum[t];
                    // rsvNum[t] = max(rsvNum[t], key + incNum[key] - t);
                    // rsvNum[key] = max(rsvNum[t], incNum[t]);
                }
            }
        }
    }
    else {
        // 删除的情况
        //#pragma omp parallel for
        for (int key = 0; key < delNum.size(); key++) {
            if (delNum[key] == 0)
                continue;
            
            // 开启计数
            // if(rsvNum[key] == -1)
            //     rsvNum[key] = 0;
            
            // 并行取max
            // if (key-1 >= 0) {
            //     for (int t = max(key-delNum[key], 0); t <= key-1; t++) {
            //         // if(rsvNum[t] == -1)
            //         //     rsvNum[t] = 0;
            //         rsvNum[t] += delNum[key];
            //         rsvNum[key] += delNum[t];
            //     }
            // }
        
            // 为求上界取最大
            rsvNum[key] = max(rsvNum[key], delNum[key]);

            if (key+1 < delNum.size()) {
                for (int t = key+1; t < delNum.size() && t <= key+delNum[key]; t++) {
                    // if(rsvNum[t] == -1)
                    //     rsvNum[t] = 0;
                    rsvNum[t] = rsvNum[t] + key + delNum[key] - t;
                    rsvNum[key] += delNum[t];
                    // rsvNum[t] = max(rsvNum[t], key + delNum[key] - t);
                    // rsvNum[key] = max(rsvNum[t], delNum[t]);
                }
            }
        }
    }

    // for(int i = 0; i < rsvNum.size(); i++) {
    //     if (rsvNum[i] > 0)
    //         std::cout << "rsvNum " << i << '\t' << rsvNum[i] << std::endl;
    // }

    // 并行 d ∈ V;
    // std::cout << "modFrontierParallel begins" << std::endl;
    // futures.clear();
    // vector<int> A; //frontier
    // for (int d = 0; d < vertexNum; d++) {
    //     futures.emplace_back(pool.enqueue(&ScalableHypergraph::modFrontierParallel, this, d, delNum, rsvNum, A));
    // }
    // for (auto &f: futures) {
    //     f.get();
    // }

    frontier.clear();
    frontier.resize(vertexNum, false);

    // @brief modFrontierParallel
    #pragma omp parallel for
    for (int d = 0; d < vertexNum; d++) {
        coreV[d] += rsvNum[coreV[d]];
        if(coreV[d] > rsvNum.size() || rsvNum[coreV[d]] >= 0 || delNum[coreV[d]] > 0)
            frontier[d] = true;
    }

    //std::cout << "A size:" << "\t" << A.size() << std::endl;
    //std::cout << "mod hhcLocal begins" << std::endl;
    //hhcLocal();
    paraCoreDec();
    //std::cout << "mod hhcLocal ends" << std::endl;
    //compare();
}
/**
 * Algorithm 4 Parallel Part 1
 */
void ScalableHypergraph :: modParallel(int key, vector<int> &incNum, vector<int> &delNum, vector<int> &rsvNum) {
    if (incNum[key] == 0)
        return;
    
    // 并行取max
    if (key-1 >= 0) {
        for (int t = max(key-delNum[key], 0); t <= key-1; t++) {
            rsvNum[t] += incNum[key];
            rsvNum[key] += incNum[t];            
        }
    }

    // 为求上界取最大
    rsvNum[key] = max(rsvNum[key], incNum[key]);
    
    if (key+1 < incNum.size()) {
        for (int t = key+1; t < incNum.size() && t <= key+incNum[key]; t++) {
            rsvNum[t] = rsvNum[t] + key + incNum[key] - t;
            rsvNum[key] += incNum[t];
    }
}
}
/**
 * Algorithm 4 Parallel Part 2
 */
void ScalableHypergraph :: modFrontierParallel(int d, vector<int> &delNum, vector<int> &rsvNum, vector<int> &A) {
    coreV[d] += rsvNum[coreV[d]];
    if (coreV[d] > rsvNum.size() || rsvNum[coreV[d]] >= 0 || delNum[coreV[d]] > 0)
        A.push_back(d);
}

/**
 * @brief 求差集
 * @param vec1 被减集合 @param vec2 减集合 @param result 结果
 */
void ScalableHypergraph :: quotient(const vector<int> &vec1, const vector<int> &vec2, vector<int> &result) {
    for (auto itr : vec1) {
        //未查到则push back
        if (find(vec2.begin(), vec2.end(), itr) == vec2.end())
            result.push_back(itr);
    }
}
/**
 * @brief 求并集
 * @param vec1 原集合 @param vec2 原集合 @param result 结果
 */
void ScalableHypergraph :: unionset(vector<int> &vec1, vector<int> &vec2, vector<int> &result) {
    //merge 合并
    sort(vec1.begin(), vec1.end());
    sort(vec2.begin(), vec2.end());
    result.resize(vec1.size()+vec2.size());
    merge(vec1.begin(), vec1.end(), vec2.begin(), vec2.end(), result.begin());
    //去重
    sort(result.begin(),result.end());
    result.erase(unique(result.begin(), result.end()), result.end());
}
void ScalableHypergraph :: fset(vector<batch> &batchset, vector<int> &A, vector<vector<int>> &U) {
    /**
     * pin.first.first: edge
     * pin.first.second: vertex
     * pin.second: c
     */
    //std::cout << "fset begins" << std::endl;
    for (auto pin : batchset) {
        A[pin.first.second] = 2;
        //U[vb] = U[vb] ∪ {id(ea)}
        if (pin.second) {
            if (find(U[pin.first.second].begin(), U[pin.first.second].end(), pin.first.first) == U[pin.first.second].end())
                U[pin.first.second].push_back(pin.first.first);
        }
    }
    std::cout << "batchset size:"<< '\t' << batchset.size() << std::endl;
}
/**
 * Algorithm 5: The set algorithm, which mixes incrementing τ and converging τ.
 * The id function resets each batch and increments on distinct ea inputs.
 * Data: hypergraph H = (V, E), local values τ
 * Input: batch edge set B
 */
void ScalableHypergraph :: set(unordered_map<int, vector<int>> &mpVert, vector<batch> &batchset, bool IorD) {
    // 运行时不动态调整线程数
    omp_set_dynamic(0);
    omp_set_num_threads(threadNum);
    /**
     * Active: 活跃次数, 初始化为2
     * Unprocessed: 初始化为所有包含对应节点的插入边数
     * Processed: 初始化为空
     */
    vector<int> Active(vertexNum, 0);
    //unordered_map<int, vector<int>> Unprocess;
    //unordered_map<int, vector<int>> Process;
    vector<vector<int>> Unprocessed;
    vector<vector<int>> Processed;
    for (int i = 0; i < vertexNum; i++) {
        Unprocessed.push_back(vector<int>(0));
        Processed.push_back(vector<int>(0));
    }

    /**
     * @brief 先插入删除节点，利用batch edge set B初始化 maintainH(f-set, B)
     */
    if (IorD)
        vertInsertion(mpVert);
    else
        vertDeletion(mpVert);
    fset(batchset, Active, Unprocessed);

    // if (IorD) {
    //     for (int i = 0; i < Active.size(); i++) {
    //         if (Active[i] != 0) {
    //             std::cout << "Active " << i << '\t' << Active[i] << std::endl;
    //             std::cout << "Unprocessed " << i << '\t';
    //             for (auto u : Unprocessed[i])
    //                 std::cout << u << '\t';
    //             std::cout << std::endl;
    //         }
    //     }
    // }
    // else{
    //     for (int i = 0; i < Active.size(); i++) {
    //         if (Active[i] != 0) {
    //             std::cout << "Active " << i << '\t' << Active[i] << std::endl;
    //         }
    //     }
    // }

    bool flagA = false;
    do {
        flagA = false;
        vector<int> tempcoreV(coreV);
        vector<vector<int>> tempUn(Unprocessed);   // Ux
        vector<vector<int>> tempP(Processed);

        // std::cout << "setParallel begins" << std::endl;
        // 并行 vertex ∈ V;
        // ThreadPool pool(threadNum);
        // vector<future<void>> futures;
        // for (int vertex = 0; vertex < vertexNum; vertex++) {
        //     futures.emplace_back(pool.enqueue(&ScalableHypergraph::setParallel, this, vertex, Active, Unprocessed, Processed, flagA));
        // }
        // for (auto &f: futures) {
        //     f.get();
        // }

        // int a = 0;
        // for (int i = 0; i < Active.size(); i++) {
        //     if (Active[i] != 0)
        //         a++;
        // }
        // std::cout << "Active " << a << std::endl;

        // @brief setParallel
        #pragma omp parallel for
        for (int vertex = 0; vertex < vertexNum; vertex++) {
            if (Active[vertex] == 0)
                continue;

            //vector<int> tempU(Unprocessed[vertex]); // Ux
            vector<int> tempEdge;
            vector<int> tempNeighbor;
            vector<int> L;
            // std::cout << "Unprocessed tempU " << vertex << '\t';
            // for (int i = 0; i < tempUn[vertex].size(); i++) {
            //     std::cout << tempUn[vertex][i] << '\t';
            // }
            // std::cout << std::endl;
            for (auto edge : vvVertices[vertex]) {
                tempEdge.push_back(edge);
            }
            for (auto edge : tempEdge) {
                // 有除了vertex 以外的节点(邻居)
                if (vvEdges[edge].size() > 1) {
                    //std::cout << vertex << "\t" << "on edge " << edge << std::endl;
                    // for (auto neighbor : vvEdges[edge]) {
                    //     std::cout << neighbor << '\t' << coreV[neighbor] << std::endl;
                    // }
                    int min_val = INFINITE;
                    for (auto neighbor : vvEdges[edge]) {
                        //if (neighbor != vertex) {
                            tempNeighbor.push_back(neighbor);
                            // t = τ[n] + |U[n] ∪ (Ux \ P[n])|
                            vector<int> temp1;
                            quotient(tempUn[vertex], tempP[neighbor], temp1);
                            //unionset(Unprocessed[neighbor], temp1, temp1);
                            for (auto itr : tempUn[neighbor]) {
                                if (find(temp1.begin(), temp1.end(), itr) == temp1.end()) {
                                    temp1.push_back(itr);
                                    //std::cout << "Unprocessed " << neighbor << " push_back" << itr << std::endl;
                                }
                            }
                            int t = tempcoreV[neighbor] + temp1.size();
                            //std::cout << neighbor << '\t' << "coreV:" << coreV[neighbor] << " |temp|:" << temp2.size() << std::endl;
                            min_val = min(min_val, t);
                        //}
                    }
                    //std::cout << vertex  << " on edge " << edge << '\t' << "min_val: " << min_val << std::endl;
                    L.push_back(min_val);
                }
            }
            // 去重
            sort(tempNeighbor.begin(),tempNeighbor.end());
            tempNeighbor.erase(unique(tempNeighbor.begin(), tempNeighbor.end()), tempNeighbor.end());
        
            int h_index = HIndex(L);
            //std::cout << vertex << '\t' << "h_index: " << h_index << std::endl;
            if (h_index != tempcoreV[vertex]) {
                for (auto neighbor : tempNeighbor) {
                    // U[n] = U[n] ∪ (Ux \ P[n])
                    vector<int> temp1;
                    quotient(tempUn[vertex], tempP[neighbor], temp1);
                    // unionset(U[neighbor], temp1, U[neighbor]) 初始化P?
                    for (auto itr : temp1) {
                        if (find(Unprocessed[neighbor].begin(), Unprocessed[neighbor].end(), itr) == Unprocessed[neighbor].end()) {
                            Unprocessed[neighbor].push_back(itr);
                            //std::cout << "Unprocessed " << neighbor << " push_back" << itr << std::endl;
                        }
                    }
                    Active[neighbor] = 2;
                    //std::cout << "Active " << neighbor << '\t' << Active[neighbor] << std::endl;
                }
                coreV[vertex] = h_index;
                Active[vertex] = 2;
                //std::cout << "Active " << vertex << '\t' << Active[vertex] << std::endl;
            }
            else {
                Active[vertex] -= 1;
                //std::cout << "Active " << vertex << '\t' << Active[vertex] << std::endl;
            }
           
            //将Ux归为已处理, P[x] = P[x] ∪ Ux, U[x] = U[x] \ Ux;
            //unionset(P[vertex], tempU, P[vertex])
            //std::cout << "Processed union Ux" << std::endl;
            for (auto itr : tempUn[vertex]) {
                if(find(Processed[vertex].begin(), Processed[vertex].end(), itr) == Processed[vertex].end())
                    Processed[vertex].push_back(itr);
            }
            //quotient(U[vertex], tempU, U[vertex])
            //std::cout << "Unprocessed quotient Ux" << std::endl;
            vector<int> temp1;
            quotient(Unprocessed[vertex], tempUn[vertex], temp1);
            //std::swap(Unprocessed[vertex], temp1);
            Unprocessed[vertex].clear();
            Unprocessed[vertex].assign(temp1.begin(), temp1.end());
            //flip flag
            flagA = true;
        }

        //swap(coreV, tempcoreV);
    } while(flagA);
    //compare();
}
/**
 * Algorithm 5 Parallel Part
 */
void ScalableHypergraph :: setParallel(int vertex, vector<int> &Active, vector<vector<int>> &Unprocessed, vector<vector<int>> &Processed, vector<int> &tempcoreV, bool &flagA) {
    if (Active[vertex] == 0)
        return;
    
    vector<int> tempU(Unprocessed[vertex]);//Ux
    vector<int> tempEdge;
    vector<int> tempNeighbor;
    vector<int> L;
    for (auto edge : vvVertices[vertex]) {
        tempEdge.push_back(edge);
    }
    for (auto edge : tempEdge) {
        // 有除了vertex 以外的节点(邻居)
        if (vvEdges[edge].size() > 1) {
            int min_val = INFINITE;
            for (auto neighbor : vvEdges[edge]) {
                if (neighbor != vertex) {
                    tempNeighbor.push_back(neighbor);
                    // t = τ[n] + |U[n] ∪ (Ux \ P[n])|
                    vector<int> temp1, temp2;
                    quotient(tempU, Processed[neighbor], temp1);
                    unionset(Unprocessed[neighbor], temp1, temp2);
                    int t = coreV[neighbor] + temp2.size();
                    min_val = min(min_val, t);
                }
            }
            L.push_back(min_val);
        }
    }
    sort(tempNeighbor.begin(),tempNeighbor.end());
    tempNeighbor.erase(unique(tempNeighbor.begin(), tempNeighbor.end()), tempNeighbor.end());

    int h_index = HIndex(L);
    if (h_index != coreV[vertex]) {
        for (auto neighbor : tempNeighbor) {
            // U[n] = U[n] ∪ (Ux \ P[n])
            vector<int> temp1;
            quotient(tempU, Processed[neighbor], temp1);
            // unionset(U[neighbor], temp1, U[neighbor]) 初始化P?
            for (auto itr : temp1) {
                if(find(Unprocessed[neighbor].begin(), Unprocessed[neighbor].end(), itr) == Unprocessed[neighbor].end())
                    Unprocessed[neighbor].push_back(itr);
            }
            Active[neighbor] = 2;
        }
        tempcoreV[vertex] = h_index;
        Active[vertex] = 2;
    }
    else
        Active[vertex] -= 1;
    
    // 将Ux归为已处理, P[x] = P[x] ∪ Ux, U[x] = U[x] \ Ux;
    // unionset(P[vertex], tempU, P[vertex])
    for (auto itr : tempU) {
        if(find(Processed[vertex].begin(), Processed[vertex].end(), itr) == Processed[vertex].end())
            Processed[vertex].push_back(itr);
    }
    // quotient(U[vertex], tempU, U[vertex])
    vector<int> temp1;
    quotient(Unprocessed[vertex], tempU, temp1);
    swap(Unprocessed[vertex], temp1);
    // flip flag
    flagA = true;
}


/**
 * @brief map to batchset
 * 
 * @param mpVert map
 * @param batchset batchset
 * @param IorD insert-true delete-false
 */
void ScalableHypergraph :: mapToBatch(unordered_map<int, vector<int>> &mpVert, vector<batch> &batchset, bool IorD) {
    //std::cout << "mapToBatch begins" << std::endl;
    for (auto it = mpVert.begin(); it != mpVert.end(); it++) {
        //int edge = it->first;
        //vector<int> vVert = it->second;
        for (auto vit : it->second) {
            batch temp_pair(make_pair(it->first,vit), IorD);
            batchset.push_back(temp_pair);
        }
    }
    //std::cout << "mapToBatch ends" << std::endl;
}
void ScalableHypergraph :: changeBatch(vector<batch> &batchset, bool IorD) {
    //std::cout << "changeBatch begins" << std::endl;     
    for (auto &it : batchset) {
        it.second = IorD;
    }
    //std::cout << "changeBatch ends" << std::endl;    
}

// Graph Maintain Algorithm
/**
 * @brief 插入超边
 */
void ScalableHypergraph :: addEdge(vector<int> edge) {
    // 这里不考虑超边重复的情况，请确保输入的数据没有重复的边，似乎支持存在重复边
    // 对于节点数小于2的边直接忽略
    // if (edge.size() < 2)
    // {
    //     return;
    // }
    int num = vvEdges.size();    // 插入的这条边的序号
    vvEdges.push_back(edge);    // 插入边
    edgeNum += 1;
    // 插入节点
    for (int i = 0; i < edge.size(); i++) {
        while (edge[i] + 1 > vertexNum) {
            vvVertices.push_back(vector<int>(0));
            vertexNum += 1;
        }
        vvVertices[edge[i]].push_back(num);
    }
    return;
}

/**
 * @brief 批量删除节点
 * 
 * @param mpDeletedVert 
 */
void ScalableHypergraph :: vertDeletion(unordered_map<int, vector<int>> &mpDeletedVert) {
    for (auto it = mpDeletedVert.begin(); it != mpDeletedVert.end(); it++) {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (deleteVertFromEdge(edge, vVert) == false) {
            std::cout << "vertDeletion failed" << std::endl;
            return;
        }
    }
    std::cout << "vertDeletion finished" << std::endl;
    return;
}
/**
 * @brief 在超边中删除节点
 * @param e: 超边
 * @param vecV: 待删除的节点集
 * @return true ：删除成功
 * @return false ：删除失败
 */
bool ScalableHypergraph :: deleteVertFromEdge(int e, vector<int> &vecV) {
    int edge = e;
    vector<int> vVert = vecV;
    if (edge >= edgeNum) {
        cout << "deleted edge is out of range" << endl;
        return false;
    }
    vector<int> oldVert = vvEdges[edge];    // 边edge原先拥有的节点
    if (oldVert.size() - vVert.size() < 0) {
        return false;
    }
    // 在vvEdges中删除超边中的节点
    unordered_set<int> usVert(oldVert.begin(), oldVert.end());
    for (int i = 0; i < vVert.size(); i++) {
        if (usVert.find(vVert[i]) == usVert.end()) {
            return false;
        }
        usVert.erase(usVert.find(vVert[i]));
    }
    vector<int> newVert(usVert.begin(), usVert.end());
    // if (newVert.size() < 2)
    // {
    //     // 相当于这条超边已经不存在了
    //     vvEdges[edge].clear();
    //     vVert.insert(vVert.end(), newVert.begin(), newVert.end());
    // }
    // else
    // {
    //     vvEdges[edge] = newVert;
    // }
    vvEdges[edge] = newVert;
    // 在vvVertices中删除包含这个节点的超边
    for (int i = 0; i < vVert.size(); i++) {
        vector<int> oldEdge = vvVertices[vVert[i]];
        vector<int> newEdge;
        for (int j = 0; j < oldEdge.size(); j++) {
            if (oldEdge[j] != edge) {
                newEdge.push_back(oldEdge[j]);
            }
        }
        vvVertices[vVert[i]] = newEdge;
    }

    return true;
}

/**
 * @brief 批量插入节点
 * 
 * @param mpInsertedVert 
 */
void ScalableHypergraph :: vertInsertion(unordered_map<int, vector<int>> &mpInsertedVert) {
    for (auto it = mpInsertedVert.begin(); it != mpInsertedVert.end(); it++) {
        int edge = it->first;
        vector<int> vVert = it->second;
        if (insertVertToEdge(edge, vVert) == false) {
            std::cout << "vertInsertion failed" << std::endl;
            return;
        }
    }
    std::cout << "vertInsertion finished" << std::endl;
    return;
}
/**
 * @brief 向超边插入节点
 * @param e 待插入节点的超边
 * @param vecV 待插入的节点集
 * @return true 
 * @return false 
 */
bool ScalableHypergraph :: insertVertToEdge(int e, vector<int> &vecV) {
    // 修改vvEdges[e]，插入节点集
    vector<int> oldVert = vvEdges[e];    // 边e原先拥有的节点
    unordered_set<int> usVert(oldVert.begin(), oldVert.end());
    for (int i = 0; i < vecV.size(); i++) {
        if (usVert.find(vecV[i]) != usVert.end()) {
            return false;
        }
        usVert.insert(vecV[i]);
    }
    vector<int> newVert(usVert.begin(), usVert.end());
    vvEdges[e] = newVert;
    // 在每个节点中添加边
    for (int i = 0; i < vecV.size(); i++) {
        vvVertices[vecV[i]].push_back(e);
    }
    return true;
}

bool ScalableHypergraph :: compare() {
    std::cout << "compare begins" << std::endl;
    if (staticCoreV.size() != coreV.size()) {
        std::cout << "compare failed" << std::endl;
        return false;
    }
    for (int i = 0; i < coreV.size(); i++) {
        if (staticCoreV[i] != coreV[i]) {
            std::cout << i << '\t' << "staticCoreV: " << staticCoreV[i] << '\t' << "coreV: " << coreV[i] << std::endl;
            //return false;
        }
    }
    std::cout << "compare finished" << std::endl;
    return true;
}

vector<int> ScalableHypergraph :: coreDecomp() {
    int a = 0;
    int b = 0;
    vector<int> bin, pos, vert, deg;
    int maxDegree = 0;
    int n = vertexNum;
    for (int u = 0; u < n; u++)
    {
        pos.push_back(0);
        vert.push_back(0);
        int uSize = vvVertices[u].size();
        deg.push_back(uSize);
        maxDegree = (maxDegree > uSize) ? maxDegree : uSize;
    }
    for (int k = 0; k <= maxDegree; k++)
    {
        bin.push_back(0);
    }
    for (int u = 0; u < n; u++)
    {
        bin[deg[u]]++;
    }
    int start = 0;
    for (int k = 0; k <= maxDegree; k++)
    {
        int num = bin[k];
        bin[k] = start;
        start += num;
    }
    for (int u = 0; u < n; u++)
    {
        pos[u] = bin[deg[u]];
        vert[pos[u]] = u;
        bin[deg[u]]++;
    }
    for (int d = maxDegree; d > 0; d--)
    {
        bin[d] = bin[d-1];
    }
    bin[0] = 0;
    int du, pu, pw, w;
    unordered_set<int> sEdges;
    for (int i = 0; i < n; i++)
    {
        int v = vert[i];
        for (int j = 0; j < vvVertices[v].size(); j++)
        {
            int e = vvVertices[v][j];
            if (sEdges.find(e) != sEdges.end())
            {
                continue;
            }
            sEdges.insert(e);
            vector<int> neighbor = vvEdges[e];
            for (int k = 0; k < neighbor.size(); k++)
            {
                int u = neighbor[k];
                if (u != v && deg[u] > deg[v])
                {
                    du = deg[u];
                    pu = pos[u];
                    pw = bin[du];
                    w = vert[pw];
                    if (u != w)
                    {
                        pos[u] = pw;
                        vert[pu] = w;
                        pos[w] = pu;
                        vert[pw] = u;
                    }
                    bin[du]++;
                    deg[u]--;
                }
            }
        }
    }
    return deg;
}

void ScalableHypergraph :: paraCoreDec() {
    omp_set_dynamic(0);
    omp_set_num_threads(threadNum);

    vector<bool> v_list(frontier);
    // v_list.resize(vertexNum, true);
    vector<bool> e_list;

    coreE.resize(edgeNum, 0);
// 初始化
// #pragma omp parallel for
//     for (int i = 0; i < vvVertices.size(); i++)
//     {
//         coreV[i] = vvVertices[i].size();
//     }

#pragma omp parallel for
    for (int i = 0; i < edgeNum; i++)
    {
        coreE[i] = vertexNum;
        for (int j = 0; j < vvEdges[i].size(); j++)
        {
            if (coreV[vvEdges[i][j]] < coreE[i])
            {
                coreE[i] = coreV[vvEdges[i][j]];
            }
        }
    }

    volatile bool flag = true;
    while (flag)
    {

        flag = false;
        e_list.resize(edgeNum, false);

#pragma omp parallel for
        for (int i = 0; i < vertexNum; i++)
        {
            if (v_list[i] && coreV[i] != 0)
            {
                int k = coreV[i];
                vector<int> count(k + 1, 0);
                for (int ii = 0; ii < vvVertices[i].size(); ii++)
                {
                    int j = std::min(k, coreE[vvVertices[i][ii]]);
                    count[j]++;
                }
                for (int m = k; m >= 1; m--)
                {
                    count[m - 1] = count[m - 1] + count[m];
                }
                int m = k;
                while (m > 0 && count[m] < m)
                {
                    m--;
                }
                if (coreV[i] > m)
                {
                    coreV[i] = m;
                    for (int ii = 0; ii < vvVertices[i].size(); ii++)
                    {
                        e_list[vvVertices[i][ii]] = true;
                    }
                }
            }
        }

        v_list.resize(vertexNum, false);

#pragma omp parallel for
        for (int i = 0; i < edgeNum; i++)
        {
            if (e_list[i])
            {
                int min = coreE[i];
                for (int j = 0; j < vvEdges[i].size(); j++)
                {
                    min = std::min(min, coreV[vvEdges[i][j]]);
                }
                if (min < coreE[i])
                {
                    coreE[i] = min;
                    flag = true;
                    for (int j = 0; j < vvEdges[i].size(); j++)
                    {
                        v_list[vvEdges[i][j]] = true;
                    }
                }
            }
        }
    }
}