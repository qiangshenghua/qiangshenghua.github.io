#ifndef SCALABLEHYPERGRAPH_H
#define SCALABLEHYPERGRAPH_H

#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <stack>
#include <queue>
#include <algorithm>
#include <utility>
#include <omp.h>
#include "threadpool.h"

using namespace std;

const int INFINITE = 0x7fffffff;
typedef pair<pair<int, int>, bool> batch;

class ScalableHypergraph {
public:
    int edgeNum;        // 超边数
    int vertexNum;      // 节点数
    vector<int> coreV;  // 节点核值
    vector<int> coreE;  // 边核值
    vector<int> staticCoreV;    //  初始节点核值, 用以对比
    vector<bool> frontier;      //  每轮迭代节点状态, true - 收敛; false - 未收敛
    vector<vector<int>> vvVertices;     // vvVertices[i]表示节点i所属的超边的集合
    vector<vector<int>> vvEdges;        // vvEdges[i]表示超边i所包含的节点集合
    int threadNum;      // 线程数

    ScalableHypergraph() {edgeNum = 0; vertexNum = 0;};
    ~ScalableHypergraph() {};
    void setThreadNum(int number) {threadNum = number;};

    //Core Value Maintain Algorithm
    void statichhcLocal();
    void mod(unordered_map<int, vector<int>> &mpVert, vector<batch> &batchset, bool IorD);
    void set(unordered_map<int, vector<int>> &mpVert, vector<batch> &batchset, bool IorD);
    vector<int> coreDecomp();
    void paraCoreDec();

    //Graph Maintain Algorithm
    void addEdge(vector<int> edge);
    void mapToBatch(unordered_map<int, vector<int>> &mpVert, vector<batch> &batchset, bool IorD);
    void changeBatch(vector<batch> &batchset, bool IorD);
    bool compare();

    void vertDeletion(unordered_map<int, vector<int>> &mpDeletedVert);
    void vertInsertion(unordered_map<int, vector<int>> &mpInsertedVert);

private:
    //Core Value Maintain Algorithm
    int HIndex(vector<int> &L);
    void hhcLocal();
    void hhcLocalParallel(int vertex, vector<int> &updated_frontier, vector<int> &tempcoreV);

    void fmod(vector<batch> &batchset, vector<int> &incNum, vector<int> &delNum);
    void modParallel(int key, vector<int> &incNum, vector<int> &delNum, vector<int> &rsvNum);
    void modFrontierParallel(int d, vector<int> &delNum, vector<int> &rsvNum, vector<int> &A);

    void quotient(const vector<int> &vec1, const vector<int> &vec2, vector<int> &result);
    void unionset(vector<int> &vec1, vector<int> &vec2, vector<int> &result);
    void fset(vector<batch> &batchset, vector<int> &A, vector<vector<int>> &U);
    void setParallel(int vertex, vector<int> &Active, vector<vector<int>> &Unprocessed, vector<vector<int>> &Processed, vector<int> &tempcoreV, bool &flagA);

    //Graph Maintain Algorithm

    bool deleteVertFromEdge(int e, vector<int> &vecV);
    bool insertVertToEdge(int e, vector<int> &vecV);

};

#endif//SCALABLEHYPERGRAPH_H